//
//
//  MGRTableViewController.m
//  shakeAnimation
//
//  Created by Kwan Hyun Son on 15/05/2019.
//  Copyright © 2019 Mulgrim Inc. All rights reserved.
//

#import "MainTableViewController.h"
#import "ItemsForTableView.h"
#import "Item.h"
#import "ViewController1.h"
#import "ViewController2.h"
#import "ViewController3.h"

@interface MainTableViewController ()
@end

@implementation MainTableViewController

- (instancetype)initWithStyle:(UITableViewStyle)style {
    self = [super initWithStyle:UITableViewStylePlain]; /// UITableViewStyleGrouped <- 나머지 한 가지 스타일. 더 잘보임!!!
    if(self) {
        self.navigationItem.title = @"Segmented Control";
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(settingsDidUpdatex:)
                                                 name:NSUserDefaultsDidChangeNotification
                                               object:nil];
}

- (void)settingsDidUpdatex:(NSNotification *)notification {
    NSLog(@"노티피케이션 알림 왔다. %@ %@ %@", notification.name, notification.object, notification.userInfo);
}


#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return ItemsForTableView.sharedItems.allItems.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"jotto"];
    if (cell == nil) { // NSLog(@"처음만들어");
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"jotto"];
    } else { // NSLog(@"재사용이야");
    }
    
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator; /// 오른쪽에 > 표시를 만든다.
    
    NSArray *itemsArray = ItemsForTableView.sharedItems.allItems;
    Item *item = itemsArray[indexPath.row];
    cell.textLabel.text = item.textLabelText;
    cell.detailTextLabel.text = item.detailTextLabelText;
    
    return cell;
}


#pragma mark - <UITableViewDelegate> 메서드
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if(indexPath.row == 0){
        [self.navigationController pushViewController:[ViewController1 new] animated:YES];
    }
    else if(indexPath.row == 1) {
        [self.navigationController pushViewController:[ViewController2 new] animated:YES];
    }
    else if(indexPath.row == 2) {
        [self.navigationController pushViewController:[ViewController3 new] animated:YES];
    }
}

@end
