//
//  ViewController3.m
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/13.
//

#import "ViewController3.h"
#import "RESegmentedControl.h"

@interface ViewController3 ()
@property (nonatomic, strong) NSArray <NSString *>*items;
@property (nonatomic, strong) RESegmentedControlPreset *customSimple3preset;

@property (weak, nonatomic) IBOutlet RESegmentedControl *ios7SegmentedControl;
@property (weak, nonatomic) IBOutlet RESegmentedControl *ios13SegmentedControl;
@property (weak, nonatomic) IBOutlet RESegmentedControl *materialSegmentedControl;

@property (weak, nonatomic) IBOutlet RESegmentedControl *customSimple1SegmentedControl;
@property (weak, nonatomic) IBOutlet RESegmentedControl *customSimple2SegmentedControl;
@property (weak, nonatomic) IBOutlet RESegmentedControl *customSimple3SegmentedControl;
@property (weak, nonatomic) IBOutlet RESegmentedControl *customSimple4SegmentedControl;
@property (weak, nonatomic) IBOutlet RESegmentedControl *customSimple5SegmentedControl;
@end

@implementation ViewController3

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"Style Presets Example";
    _items = @[@"Movie", @"TV Show", @"Cartoons"];
    
    NSArray <SegmentModel *>*segmentItems =
    @[[[SegmentModel alloc] initWithTitle:self.items[0]],
      [[SegmentModel alloc] initWithTitle:self.items[1]],
      [[SegmentModel alloc] initWithTitle:self.items[2]]];
    NSArray <SegmentModel *>*segmentItemsUpper =
    @[[[SegmentModel alloc] initWithTitle:self.items[0].uppercaseString],
      [[SegmentModel alloc] initWithTitle:self.items[1].uppercaseString],
      [[SegmentModel alloc] initWithTitle:self.items[2].uppercaseString]];
    
    _customSimple3preset = [RESegmentedControlPreset defaultConfiguration];
    self.customSimple3preset.segmentBorderWidth = 2.0f;
    self.customSimple3preset.segmentBorderColor =
    [UIColor colorWithRed:0.6000000238 green:0.6000000238 blue:0.6000000238 alpha:1.0].CGColor;
    self.customSimple3preset.textFont = [UIFont systemFontOfSize:11.0f weight:UIFontWeightBold];
    self.customSimple3preset.selectedTextFont = [UIFont systemFontOfSize:11.0f weight:UIFontWeightBold];
    
    
    UIColor *selectedBackgroundColor;
    if (@available(iOS 11, *)) {
        selectedBackgroundColor = [UIColor colorNamed:@"darkBlack"]; // Asset에 저장되어있음.
    }
    if (selectedBackgroundColor == nil) {
        selectedBackgroundColor = [UIColor blackColor];
    }
    
    self.customSimple3preset.backgroundColor = [UIColor clearColor];
    self.customSimple3preset.selectedSegmentItemColor = selectedBackgroundColor;
    self.customSimple3preset.textColor = [UIColor colorWithRed:0.6000000238 green:0.6000000238 blue:0.6000000238 alpha:1.0];
    self.customSimple3preset.selectedTextColor = [UIColor whiteColor];
    
    
    UIColor *tintColor = [UIColor colorWithRed:0.0 green:122.0/255.0 blue:1.0 alpha:1.0];
    RESegmentedControlPreset *preset = [RESegmentedControlPreset iOS7PresetConfigurationWithTintColor:tintColor];
    [self.ios7SegmentedControl configureSegmentItems:segmentItems preset:preset selectedIndex:0];
    
    preset = [RESegmentedControlPreset iOS13PresetConfiguration];
    [self.ios13SegmentedControl configureSegmentItems:segmentItems preset:preset selectedIndex:0];
    
    
    preset = [RESegmentedControlPreset materialConfigurationWithBackgroundColor:UIColor.orangeColor
                                                                      tintColor:UIColor.blackColor];
    [self.materialSegmentedControl configureSegmentItems:segmentItemsUpper preset:preset selectedIndex:0];

    
    
    UIColor *backgroundColor;
    if (@available(iOS 11, *)) {
        backgroundColor = [UIColor colorNamed:@"darkBlack"]; // Asset에 저장되어있음.
    }
    if (backgroundColor == nil) {
        backgroundColor = [UIColor blackColor];
    }
    
    preset = [RESegmentedControlPreset defaultConfiguration];
    preset.textFont = [UIFont systemFontOfSize:11.0f weight:UIFontWeightBold];
    preset.selectedTextFont = [UIFont systemFontOfSize:11.0f weight:UIFontWeightBold];
    preset.selectedSegmentItemOffset = 2.0f;
    preset.textColor = [UIColor lightGrayColor];
    preset.selectedTextColor = [UIColor whiteColor];
    preset.backgroundColor = backgroundColor;
    preset.selectedSegmentItemColor = [UIColor darkGrayColor];
    [self.customSimple1SegmentedControl configureSegmentItems:segmentItemsUpper preset:preset selectedIndex:0];


    preset = [RESegmentedControlPreset defaultConfiguration];
    preset.segmentItemBorderWidth = 1.0f;
    preset.segmentItemBorderColor =
    [UIColor colorWithRed:0.9333333333 green:0.9333333333 blue:0.9333333333 alpha:1.0].CGColor;
    preset.textFont = [UIFont systemFontOfSize:11.0f weight:UIFontWeightBold];
    preset.selectedTextFont = [UIFont systemFontOfSize:11.0f weight:UIFontWeightBold];
    preset.backgroundColor = [UIColor whiteColor];
    preset.selectedSegmentItemColor =
    [UIColor colorWithRed:0.9843137255 green:0.7568627451 blue:0.03529411765 alpha:1.0];
    [self.customSimple2SegmentedControl configureSegmentItems:segmentItemsUpper preset:preset selectedIndex:0];
    
    
    [self.customSimple3SegmentedControl configureSegmentItems:segmentItemsUpper preset:self.customSimple3preset selectedIndex:0];
    
    
    UIColor *textColor;
    if (@available(iOS 13, *)) {
        textColor = [UIColor labelColor];
    }
    if (textColor == nil) {
        textColor = [UIColor blackColor];
    }
    preset = [RESegmentedControlPreset defaultConfiguration];
    preset.segmentSpacing = 15.0;
    preset.selectedSegmentItemCornerRadius = 10.0;
    preset.textFont = [UIFont systemFontOfSize:11.0f weight:UIFontWeightBold];
    preset.selectedTextFont = [UIFont systemFontOfSize:11.0f weight:UIFontWeightBold];
    preset.selectedSegmentItemShadowHidden = NO;
    preset.selectedSegmentItemShadowColor = [UIColor blackColor].CGColor;
    preset.selectedSegmentItemShadowOpacity = 0.3f;
    preset.selectedSegmentItemShadowOffset = CGSizeZero;
    preset.selectedSegmentItemShadowRadius = 10.f;
    preset.selectedSegmentItemShadowPath = NULL;
    preset.backgroundColor = [UIColor clearColor];
    preset.selectedSegmentItemColor =
    [UIColor colorWithRed:0.1960784346 green:0.3411764801 blue:0.1019607857 alpha:1.0];
    preset.textColor = textColor;
    preset.selectedTextColor = [UIColor whiteColor];
            
    [self.customSimple4SegmentedControl configureSegmentItems:segmentItemsUpper preset:preset selectedIndex:0];

    

    preset = [RESegmentedControlPreset defaultConfiguration];
    preset.segmentSpacing = 15.0;
    preset.segmentItemCornerRadius = 10.0;
    preset.selectedSegmentItemCornerRadius = 10.0;
    preset.textFont = [UIFont systemFontOfSize:11.0f weight:UIFontWeightBold];
    preset.selectedTextFont = [UIFont systemFontOfSize:11.0f weight:UIFontWeightBold];
    preset.backgroundColor = [UIColor whiteColor];
    preset.selectedSegmentItemColor =
    [UIColor colorWithRed:0.8549019694 green:0.250980407 blue:0.4784313738 alpha:1.0];
    preset.selectedTextColor = [UIColor whiteColor];
    
    preset.segmentItemShadowHidden = NO;
    preset.segmentItemShadowColor = [UIColor blackColor].CGColor;
    preset.segmentItemShadowOpacity = 0.2f;
    preset.segmentItemShadowOffset = CGSizeZero;
    preset.segmentItemShadowRadius = 5.f;
    preset.segmentItemShadowPath = NULL;
    
    //self.view.clipsToBounds
    //self.view.layer //masksToBounds
    
    [self.customSimple5SegmentedControl configureSegmentItems:segmentItemsUpper preset:preset selectedIndex:0];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];

    self.customSimple3preset.selectedSegmentItemCornerRadius =
    self.customSimple3SegmentedControl.bounds.size.height / 2.0;
    self.customSimple3preset.segmentCornerRadius =
    self.customSimple3SegmentedControl.bounds.size.height / 2.0;
    self.customSimple3SegmentedControl.preset = self.customSimple3preset;
}

@end
