//
//  ViewController1.m
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/13.
//

#import "ViewController1.h"
#import "RESegmentedControl.h"

@interface ViewController1 ()
@property (nonatomic, strong) UIColor *tintColor;
@property (nonatomic, strong) NSArray <NSString *>*items;

@property (weak, nonatomic) IBOutlet RESegmentedControl *textSegmentedControl;
@property (weak, nonatomic) IBOutlet RESegmentedControl *imageSegmentedControl;
@property (weak, nonatomic) IBOutlet RESegmentedControl *verticalTextAndImageSegmentedControl;
@property (weak, nonatomic) IBOutlet RESegmentedControl *horizontalTextAndImageSegmentedControl;
@property (weak, nonatomic) IBOutlet RESegmentedControl *imageUrlSegmentedControl;
@end

@implementation ViewController1

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"Basic Layout Example";
    _tintColor = [UIColor colorWithRed:0.0 green:122.0/255.0 blue:1.0 alpha:1.0];
    _items = @[@"safari", @"chrome", @"firefox"];
    
    NSArray <SegmentModel *>*segmentItems =
    @[[[SegmentModel alloc] initWithTitle:@"safari"],
      [[SegmentModel alloc] initWithTitle:@"chrome"],
      [[SegmentModel alloc] initWithTitle:@"firefox"]];

    [self.textSegmentedControl configureSegmentItems:segmentItems
                                              preset:[RESegmentedControlPreset iOS13PresetConfiguration]
                                       selectedIndex:0];

    segmentItems =
    @[[[SegmentModel alloc] initWithTitle:nil imageName:@"safari" bundle:nil],
      [[SegmentModel alloc] initWithTitle:nil imageName:@"chrome" bundle:nil],
      [[SegmentModel alloc] initWithTitle:nil imageName:@"firefox" bundle:nil]];
    RESegmentedControlPreset *iOS7 = [RESegmentedControlPreset iOS7PresetConfigurationWithTintColor:self.tintColor];
    [self.imageSegmentedControl configureSegmentItems:segmentItems
                                               preset:iOS7
                                        selectedIndex:0];
    
    segmentItems =
    @[[[SegmentModel alloc] initWithTitle:@"safari" imageName:@"safari" bundle:nil],
      [[SegmentModel alloc] initWithTitle:@"chrome" imageName:@"chrome" bundle:nil],
      [[SegmentModel alloc] initWithTitle:@"firefox" imageName:@"firefox" bundle:nil]];
    RESegmentedControlPreset *material =
    [RESegmentedControlPreset materialConfigurationWithBackgroundColor:[UIColor orangeColor]
                                                             tintColor:[UIColor blackColor]];
    material.segmentItemAxis = UILayoutConstraintAxisVertical;
    material.spaceBetweenImageAndLabel = 0.0;
    [self.verticalTextAndImageSegmentedControl configureSegmentItems:segmentItems
                                                              preset:material
                                                       selectedIndex:0];
    
    RESegmentedControlPreset *configuration = [RESegmentedControlPreset defaultConfiguration];
    configuration.selectedSegmentItemColor =
    [UIColor colorWithRed:0.9843137255 green:0.7568627451 blue:0.03529411765 alpha:1.0];
    configuration.segmentItemBorderWidth = 1.0f;
    configuration.segmentItemBorderColor =
    [UIColor colorWithRed:0.9333333333 green:0.9333333333 blue:0.9333333333 alpha:1.0].CGColor;
    configuration.textFont = [UIFont systemFontOfSize:11.0 weight:UIFontWeightBold];
    
    [self.horizontalTextAndImageSegmentedControl configureSegmentItems:segmentItems
                                                                preset:configuration
                                                         selectedIndex:0];
    
    
    NSArray <NSString *>*urls =
    @[@"https://github.com/sh-khashimov/RESegmentedControl/blob/master/Images/browsers/safari.png?raw=true",
      @"https://github.com/sh-khashimov/RESegmentedControl/blob/master/Images/browsers/chrome.png?raw=true",
      @"https://github.com/sh-khashimov/RESegmentedControl/blob/master/Images/browsers/firefox.png?raw=true"];
    segmentItems =
    @[[[SegmentModel alloc] initWithTitle:nil imageUrl:urls[0]],
      [[SegmentModel alloc] initWithTitle:nil imageUrl:urls[1]],
      [[SegmentModel alloc] initWithTitle:nil imageUrl:urls[2]]];
    
    [self.imageUrlSegmentedControl configureSegmentItems:segmentItems
                                               preset:iOS7
                                        selectedIndex:0];
}



@end



//@IBOutlet weak var verticalTextAndImageSegment: RESegmentedControl! {
//    didSet {
//
//        var segmentItems: [SegmentModel] {
//            return items.map({ SegmentModel(title: $0, imageName: $0) })
//        }
//
//        var preset = MaterialPreset(backgroundColor: .orange, tintColor: .black)
//
//        preset.segmentItemAxis = .vertical
//        preset.spaceBetweenImageAndLabel = 0
//
//        verticalTextAndImageSegment.configure(segmentItems: segmentItems, preset: preset)
//    }
//}
//
//@IBOutlet weak var horizontalTextAndImageSegment: RESegmentedControl! {
//    didSet {
//
//        var segmentItems: [SegmentModel] {
//            return items.map({ SegmentModel(title: $0, imageName: $0) })
//        }
//
//        var preset = BootstapPreset(backgroundColor: .white, selectedBackgroundColor: #colorLiteral(red: 0.9843137255, green: 0.7568627451, blue: 0.03529411765, alpha: 1))
//
//        preset.segmentItemBorderWidth = 1
//        preset.segmentItemBorderColor = #colorLiteral(red: 0.9333333333, green: 0.9333333333, blue: 0.9333333333, alpha: 1)
//
//        preset.textFont = UIFont.systemFont(ofSize: 11, weight: .bold)
//        preset.selectedTextFont = UIFont.systemFont(ofSize: 11, weight: .bold)
//
//        preset.segmentItemAxis = .horizontal
//
//        horizontalTextAndImageSegment.configure(segmentItems: segmentItems, preset: preset)
//    }
//}
//
//@IBOutlet weak var imageUrlSegment: RESegmentedControl! {
//    didSet {
//        let urls: [String?] = ["https://github.com/sh-khashimov/RESegmentedControl/blob/master/Images/browsers/safari.png?raw=true", "https://github.com/sh-khashimov/RESegmentedControl/blob/master/Images/browsers/chrome.png?raw=true", "https://github.com/sh-khashimov/RESegmentedControl/blob/master/Images/browsers/firefox.png?raw=true"]
//
//        let segmentItems: [SegmentModel] = urls.map({ SegmentModel(imageUrl: $0) })
//
//        let preset = iOS7Preset(tintColor: tintColor)
//        imageUrlSegment.configure(segmentItems: segmentItems, preset: preset)
//    }
//}
