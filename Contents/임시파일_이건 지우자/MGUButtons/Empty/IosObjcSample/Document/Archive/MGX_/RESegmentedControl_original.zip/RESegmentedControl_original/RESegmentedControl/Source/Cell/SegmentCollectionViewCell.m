//
//  SegmentCollectionViewCell.m
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/13.
//

#import "SegmentCollectionViewCell.h"
#import "SegmentModel.h"
#import "RESegmentedControlPreset.h"
#import "ImageDownloader.h"

@interface SegmentCollectionViewCell ()
@property (nonatomic, strong, nullable) RESegmentedControlPreset *style;
@property (nonatomic, strong, nullable) SegmentModel *item;
@property (nonatomic, strong) ImageDownloader *imageDownload; // lazy
@end


@implementation SegmentCollectionViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    self.contentView.backgroundColor = UIColor.clearColor;
    self.backgroundColor = UIColor.clearColor;
    self.item = nil;
    self.imageView.image = nil;
}

- (void)prepareForReuse {
    [super prepareForReuse];
    self.imageView.image = nil;
    self.item = nil;
}

- (void)setSelected:(BOOL)selected {
    BOOL change = NO;
    if (self.selected != selected) {
        change = YES;
    }
    [super setSelected:selected];
    if (change == YES) {
        [self setNeedsLayout];
        UIViewPropertyAnimator *layoutAnimator =
        [[UIViewPropertyAnimator alloc] initWithDuration:0.5
                                            dampingRatio:1.3
                                              animations:^{ [self layoutIfNeeded]; }];
        [layoutAnimator startAnimation];
    }
}

- (void)layoutSubviews {
    [super layoutSubviews];
    
    if (self.style == nil) {
        return;
    }
    
    if (self.selected == YES) {
        self.textLabel.textColor = self.style.selectedTextColor;
        self.textLabel.font = self.style.selectedTextFont;
        if (self.style.selectedTextFont == nil) {
            self.textLabel.font = self.style.textFont;
        }
        self.imageView.tintColor = self.style.selectedTintColor;
    } else {
        self.textLabel.textColor = self.style.textColor;
        self.textLabel.font = self.style.textFont;
        self.imageView.tintColor = self.style.tintColor;
    }
}


#pragma mark - 세터 & 게터
- (ImageDownloader *)imageDownload {
    if (_imageDownload == nil) {
        _imageDownload = [ImageDownloader new];
    }
    return _imageDownload;
}

- (void)setStyle:(RESegmentedControlPreset *)style {
    _style = style;
    [self configUI];
}

- (void)setItem:(SegmentModel *)item {
    _item = item;
    
    self.textLabel.text = item.title;
    if (item.title == nil) {
        self.textLabel.text = @"";
    }
    
    if (self.item.title == nil) {
        self.textLabel.hidden = YES;
    } else {
        self.textLabel.hidden = NO;
    }
    
    if (self.item.isImageAvailable == YES) {
        self.imageView.hidden = NO;
    } else {
        self.imageView.hidden = YES;
    }
}


#pragma mark - Action
- (void)configure:(SegmentModel *)item style:(RESegmentedControlPreset *)style {
    self.style = style;
    self.item = item;
}

- (void)loadImageIfNeeded {
    if (self.item.imageUrl != nil) {
        
        __weak __typeof(self)weakSelf = self;
        [self.imageDownload downloadImageUrl:self.item.imageUrl
                                  completion:^(UIImage * _Nonnull image,
                                               NSURL * _Nonnull url,
                                               NSError * _Nonnull error) {
            __strong __typeof(weakSelf) self = weakSelf;
            if (image == nil) {
                return;
            }
            
            if ([self.item.imageUrl isEqual:url] == NO) {
                return;
            }
            
            //! FIXME: self?.style?.imageRenderMode ?? .automatic
            self.imageView.image = [image imageWithRenderingMode:self.style.imageRenderMode];
        }];
        
    } else if (self.item.imageName != nil) {
        
        NSBundle *bundle = self.item.bundle;
        if (bundle == nil) {
            bundle = [NSBundle mainBundle];
        }
        
        UIImage *image = [UIImage imageNamed:self.item.imageName
                                    inBundle:bundle
               compatibleWithTraitCollection:nil];
        
        if (image != nil) {
            //! FIXME: self?.style?.imageRenderMode ?? .automatic
            self.imageView.image = [image imageWithRenderingMode:self.style.imageRenderMode];
        }
    }
}

- (void)cancelImageDownloadIfNeeded {
    if (self.item.imageUrl == nil) {
        return;
    }
    
    [self.imageDownload cancel];
}


#pragma mark - private
- (void)configUI {
    if (self.style == nil) {
        return;
    }
    
    self.stackView.spacing = self.style.spaceBetweenImageAndLabel;
    self.stackView.axis = self.style.segmentItemAxis;
    self.imageViewHeightLC.constant = self.style.imageHeight;

    if (self.style.segmentItemShadowHidden == NO) {
        self.layer.shadowColor = self.style.segmentItemShadowColor;
        self.layer.shadowOpacity = self.style.segmentItemShadowOpacity;
        self.layer.shadowOffset = self.style.segmentItemShadowOffset;
        self.layer.shadowRadius = self.style.segmentItemShadowRadius;
        self.layer.shadowPath = self.style.segmentItemShadowPath;
    }

}

@end
