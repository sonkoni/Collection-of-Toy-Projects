//
//  NSFileManager+Extention.m
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/13.
//

#import "NSFileManager+Extention.h"
#import "NSError+MGRDescription.h"
#import "NSException+MGRDescription.h"
#import "RESegmentedControl.h"

@implementation NSFileManager (Extention)

- (NSURL * _Nullable)saveImage:(NSData *)data filename:(NSString *)filename {
    NSURL *directory = [self imagesDirectory];
    if (directory == nil) {
        return nil;
    }
    
    return [self save:data filename:filename directory:directory];
}

- (NSURL * _Nullable)save:(NSData *)data filename:(NSString *)filename directory:(NSURL *)directory {
    NSURL *fileLocation = [directory URLByAppendingPathComponent:filename];
    
    @try {
        NSError *error; // 여러번의 try catch를 이용할 경우 위로 빼줘도 괜찮다.
        [data writeToURL:fileLocation
                 options:0
                   error:&error];
        [error mgrMakeExceptionAndThrow];
    } @catch(NSException *excpt) {
        [excpt mgrDescription];
    }
    
    return fileLocation;
}

- (NSData * _Nullable)imageDataFilename:(NSString *)filename {
    NSURL *directory = [self imagesDirectory];
    if (directory == nil) {
        return nil;
    }
    
    return [self dataFromDirectory:directory filename:filename];
}

- (NSData * _Nullable)dataFromDirectory:(NSURL *)directory filename:(NSString *)filename {
    NSURL *fileLocation = [directory URLByAppendingPathComponent:filename];
    NSData *data = nil;
    @try {
        NSError *error; // 여러번의 try catch를 이용할 경우 위로 빼줘도 괜찮다.
        data = [NSData dataWithContentsOfURL:fileLocation options:0 error:&error];
        [error mgrMakeExceptionAndThrow];
        
    } @catch(NSException *excpt) {
        [excpt mgrDescription];
        return nil;
    }
    return data;
}

- (void)removeImagesDirectory {
    NSURL *imagesDirectory = [self imagesDirectory];
    if (imagesDirectory == nil) {
        return;
    }
    
    @try {
        NSError *error; // 여러번의 try catch를 이용할 경우 위로 빼줘도 괜찮다.
        [self removeItemAtURL:imagesDirectory
                        error:&error];
        [error mgrMakeExceptionAndThrow];
    } @catch(NSException *excpt) {
        [excpt mgrDescription];
    }
}


#pragma mark - Private
- (NSURL * _Nullable)imagesDirectory {
    NSURL *directory = [self directory];
    if (directory == nil) {
        return nil;
    }
    
    NSURL *imagesDirectory = [directory URLByAppendingPathComponent:@"images" isDirectory:YES];
    
    @try {
        NSError *error; // 여러번의 try catch를 이용할 경우 위로 빼줘도 괜찮다.
        [self createDirectoryAtPath:imagesDirectory.path
        withIntermediateDirectories:YES
                         attributes:nil
                              error:&error];
        [error mgrMakeExceptionAndThrow];
    } @catch(NSException *excpt) {
        [excpt mgrDescription];
    }
    
    return imagesDirectory;
}

/// Bundle directory in cache directory
- (NSURL * _Nullable)directory {
    NSURL *cacheDirectory = [self URLsForDirectory:NSCachesDirectory
                                         inDomains:NSUserDomainMask].firstObject;
    
    NSString *bundleIdentifier = [self bundleIdentifier];
    if (cacheDirectory == nil || bundleIdentifier == nil) {
        return nil;
    }
    
    NSURL *directory = [cacheDirectory URLByAppendingPathComponent:bundleIdentifier isDirectory:YES];

    @try {
        NSError *error; // 여러번의 try catch를 이용할 경우 위로 빼줘도 괜찮다.
        [self createDirectoryAtPath:directory.path
        withIntermediateDirectories:YES
                         attributes:nil
                              error:&error];
        [error mgrMakeExceptionAndThrow];
    } @catch(NSException *excpt) {
        [excpt mgrDescription];
    }

    return directory;
}

- (NSString * _Nullable)bundleIdentifier {
    NSBundle *bundle = [NSBundle bundleForClass:[RESegmentedControl class]];
    return bundle.bundleIdentifier;
}

@end
