//
//  RESegmentedControl.h
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/13.
//

#import <UIKit/UIKit.h>
#import "RESegmentedControlPreset.h"
#import "SegmentModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface RESegmentedControl : UIControl

@property (nonatomic, strong) RESegmentedControlPreset *preset;
@property (nonatomic, assign) NSInteger selectedSegmentIndex; // 디폴트 -1;

- (void)configureSegmentItems:(NSArray <SegmentModel *>*)segmentItems
                       preset:(RESegmentedControlPreset * _Nullable)preset // 없으면 디폴트.
                selectedIndex:(NSInteger)selectedIndex; // 없으면 0

- (NSInteger)segmentItemsCount;
- (void)addItem:(SegmentModel *)item atIndex:(NSInteger)index; // index NSNotFound 이면 제일 끝에 붙인다.
- (void)removeItemAtIndex:(NSInteger)index; // index NSNotFound 이면 제일 끝을 지운다.
- (void)replaceItem:(SegmentModel *)item atIndex:(NSInteger)index;
- (void)deselect;
@end

NS_ASSUME_NONNULL_END




