//
//  SegmentCollectionViewCell.h
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/13.
//

#import <UIKit/UIKit.h>
@class SegmentModel;
@class RESegmentedControlPreset;


NS_ASSUME_NONNULL_BEGIN

@interface SegmentCollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIStackView *stackView;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *textLabel;
@property (weak, nonatomic, nullable) IBOutlet NSLayoutConstraint *imageViewHeightLC;


- (void)loadImageIfNeeded;
- (void)cancelImageDownloadIfNeeded;

- (void)configure:(SegmentModel *)item style:(RESegmentedControlPreset *)style;

@end

NS_ASSUME_NONNULL_END
