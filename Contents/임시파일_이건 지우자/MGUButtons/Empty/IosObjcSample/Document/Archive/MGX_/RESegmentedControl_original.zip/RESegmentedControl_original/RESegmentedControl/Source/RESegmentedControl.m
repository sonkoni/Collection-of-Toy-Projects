//
//  RESegmentedControl.m
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/13.
//

#import "RESegmentedControl.h"
#import "SegmentCollectionViewCell.h"
#import "BackgroundCollectionViewCell.h"
#import "SegmentModel.h"
#import "NSFileManager+Extention.h"

@interface RESegmentedControl () <UICollectionViewDataSource, UICollectionViewDelegate>
@property (nonatomic, strong) UICollectionViewFlowLayout *collectionViewFlow;
@property (nonatomic, strong) UICollectionViewFlowLayout *collectionViewFlow2;
@property (nonatomic, strong) UICollectionView *collectionView;
@property (nonatomic, strong) UICollectionView *collectionViewBackground; //Collection view that displays a list of segment's backgrounds with separator
@property (nonatomic, strong) UIView *selectedBackgroundView; // lazy
@property (nonatomic, assign) BOOL canCollectionViewUpdateLayout; // 디폴트 YES;
@property (nonatomic, strong, nullable) NSMutableArray <NSIndexPath *>*reloadItems;

@property (nonatomic, assign, readonly) CGSize itemSize; // @dynamic
@property (nonatomic, strong) NSMutableArray <SegmentModel *>*segmentItems;
@end


@implementation RESegmentedControl
@dynamic itemSize;

+ (void)clearCache {
    NSFileManager *fileManager = [NSFileManager defaultManager];
    [fileManager removeImagesDirectory];
}


#pragma mark - 인스턴스 메서드
//! 수정이 필요하다. 초기화 메서드 문제 있음.
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self commonInit];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)coder {
    self = [super initWithCoder:coder];
    if (self) {
        [self commonInit];
    }
    return self;
}

- (void)layoutSubviews {
    NSLog(@"layoutSubviews 호출됨...");
    [super layoutSubviews];
    
    CGSize itemSize = self.itemSize;

    if (self.canCollectionViewUpdateLayout == YES) {
        [self updateCollectionViewSizeWithItemSize:itemSize];
    }

    [self updateSelectedBackgroundViewFrameWithItemSize:itemSize];

}


#pragma mark - 생성 & 소멸
- (instancetype)initWithFrame:(CGRect)frame
                 segmentItems:(NSArray <SegmentModel *>*)segmentItems
                       preset:(RESegmentedControlPreset * _Nullable)preset
                selectedIndex:(NSInteger)selectedIndex { // 기본이 0
    self = [super initWithFrame:frame];
    if (self) {
        [self commonInit];
        
        if (preset == nil) {
            preset = [RESegmentedControlPreset defaultConfiguration];
        }
        
        [self configureSegmentItems:segmentItems
                             preset:preset
                      selectedIndex:selectedIndex];
    }
    return self;
}

- (void)commonInit {
    _canCollectionViewUpdateLayout = YES;
    _segmentItems = [NSMutableArray array];
    _selectedSegmentIndex = 1;
    _preset = [RESegmentedControlPreset defaultConfiguration];
    
    _collectionViewFlow = [UICollectionViewFlowLayout new];
    self.collectionViewFlow.itemSize = CGSizeMake(CGFLOAT_MIN, CGFLOAT_MIN);
    self.collectionViewFlow.sectionInset = UIEdgeInsetsZero;
    self.collectionViewFlow.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    self.collectionViewFlow.minimumInteritemSpacing = 0.0;
    self.collectionViewFlow.minimumLineSpacing = 0.0;

    
    _collectionViewFlow2 = [UICollectionViewFlowLayout new];
    self.collectionViewFlow2.itemSize = CGSizeMake(CGFLOAT_MIN, CGFLOAT_MIN);
    self.collectionViewFlow2.sectionInset = UIEdgeInsetsZero;
    self.collectionViewFlow2.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    self.collectionViewFlow2.minimumInteritemSpacing = 0.0;
    self.collectionViewFlow2.minimumLineSpacing = 0.0;

    _collectionView = [[UICollectionView alloc] initWithFrame:CGRectZero
                                         collectionViewLayout:self.collectionViewFlow];

    self.collectionView.pagingEnabled = NO;
    self.collectionView.showsHorizontalScrollIndicator = NO;
    self.collectionView.showsVerticalScrollIndicator = NO;
    self.collectionView.bounces = YES;
    self.collectionView.clipsToBounds = NO;
    self.collectionView.scrollEnabled = NO;
    self.collectionView.backgroundColor = UIColor.clearColor;

    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;

    
    NSBundle *collectionViewCellBundle = [NSBundle bundleForClass:[SegmentCollectionViewCell class]];
    UINib * cellNib = [UINib nibWithNibName:NSStringFromClass([SegmentCollectionViewCell class])
                                     bundle:collectionViewCellBundle];
    
    [self.collectionView registerNib:cellNib
          forCellWithReuseIdentifier:NSStringFromClass([SegmentCollectionViewCell class])];
    
    
    _collectionViewBackground = [[UICollectionView alloc] initWithFrame:CGRectZero
                                                   collectionViewLayout:self.collectionViewFlow2];

    self.collectionViewBackground.pagingEnabled = NO;
    self.collectionViewBackground.showsHorizontalScrollIndicator = NO;
    self.collectionViewBackground.showsVerticalScrollIndicator = NO;
    self.collectionViewBackground.bounces = YES;
    self.collectionViewBackground.clipsToBounds = NO;;
    self.collectionViewBackground.scrollEnabled = NO;
    self.collectionViewBackground.backgroundColor = UIColor.clearColor;

    self.collectionViewBackground.delegate = self;
    self.collectionViewBackground.dataSource = self;

    collectionViewCellBundle = [NSBundle bundleForClass:[BackgroundCollectionViewCell class]];
    cellNib = [UINib nibWithNibName:NSStringFromClass([BackgroundCollectionViewCell class])
                                     bundle:collectionViewCellBundle];

    [self.collectionViewBackground registerNib:cellNib
                    forCellWithReuseIdentifier:NSStringFromClass([BackgroundCollectionViewCell class])];
    
    [self addSubview:self.collectionViewBackground];
    [self.collectionViewBackground addSubview:self.selectedBackgroundView];
    [self addSubview:self.collectionView];
    [self addLayouts];
}

- (void)addLayouts {
    self.collectionView.translatesAutoresizingMaskIntoConstraints = false;
    self.collectionViewBackground.translatesAutoresizingMaskIntoConstraints = false;

    if (SegmentedControlSizeIsMaxHeight(self.preset.segmentSize) == YES) {
        [self.collectionViewBackground.topAnchor constraintEqualToAnchor:self.topAnchor].active = YES;
        [self.collectionViewBackground.bottomAnchor constraintEqualToAnchor:self.bottomAnchor].active = YES;
        [self.collectionView.topAnchor constraintEqualToAnchor:self.topAnchor].active = YES;
        [self.collectionView.bottomAnchor constraintEqualToAnchor:self.bottomAnchor].active = YES;
    } else {
        [self.collectionViewBackground.heightAnchor constraintEqualToConstant:self.preset.segmentSize.fixedHeight].active = YES;
        [self.collectionViewBackground.centerYAnchor constraintEqualToAnchor:self.centerYAnchor].active = YES;
        
        [self.collectionView.heightAnchor constraintEqualToConstant:self.preset.segmentSize.fixedHeight].active = YES;
        [self.collectionView.centerYAnchor constraintEqualToAnchor:self.centerYAnchor].active = YES;
    }
    
    [self.collectionViewBackground.leadingAnchor constraintEqualToAnchor:self.leadingAnchor].active = YES;
    [self.collectionViewBackground.trailingAnchor constraintEqualToAnchor:self.trailingAnchor].active = YES;
    [self.collectionView.leadingAnchor constraintEqualToAnchor:self.leadingAnchor].active = YES;
    [self.collectionView.trailingAnchor constraintEqualToAnchor:self.trailingAnchor].active = YES;
}


#pragma mark - 세터 & 게터
- (UIView *)selectedBackgroundView { //! lazy
    if (_selectedBackgroundView == nil) {
        _selectedBackgroundView = [UIView new];
        _selectedBackgroundView.translatesAutoresizingMaskIntoConstraints = NO;
    }
    return _selectedBackgroundView;
}

- (CGSize)itemSize {
    CGFloat collectionViewWidth = self.collectionView.bounds.size.width;
    CGFloat itemCount = (CGFloat)(self.segmentItems.count);

    CGFloat segmentsSpacing = self.preset.segmentSpacing * (itemCount - 1);
    CGFloat itemWidth = round((collectionViewWidth - segmentsSpacing) / itemCount);
    return CGSizeMake(itemWidth, self.collectionView.bounds.size.height);
}

- (void)setSelectedSegmentIndex:(NSInteger)selectedSegmentIndex {
    if (_selectedSegmentIndex != selectedSegmentIndex) {
        _selectedSegmentIndex = selectedSegmentIndex;
        
        self.canCollectionViewUpdateLayout = NO;
        [self updateLayouts];
        self.canCollectionViewUpdateLayout = YES;

        if (self.segmentItems.count == 0 ||
            self.selectedSegmentIndex == -1 ||
            self.selectedSegmentIndex >= self.segmentItems.count) {
            return;
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [self sendActionsForControlEvents:UIControlEventValueChanged];
        });
    }
}


#pragma mark - Public Action
- (void)configureSegmentItems:(NSArray <SegmentModel *>*)segmentItems
                       preset:(RESegmentedControlPreset * _Nullable)preset // 없으면 디폴트.
                selectedIndex:(NSInteger)selectedIndex { // 없으면 0
    if (preset == nil) {
        preset = [RESegmentedControlPreset defaultConfiguration];
    }
    self.segmentItems = segmentItems.mutableCopy;
    self.preset = preset;
    [self updateLayouts];

    if (segmentItems.count > 0) {
        self.selectedSegmentIndex = selectedIndex;
    } else {
        self.selectedSegmentIndex = -1;
    }
}

- (NSInteger)segmentItemsCount {
    return self.segmentItems.count;
}

- (void)addItem:(SegmentModel *)item atIndex:(NSInteger)index {
    if (index != NSNotFound && index < self.segmentItems.count) {
        [self.segmentItems insertObject:item atIndex:index];
    } else {
        [self.segmentItems addObject:item];
    }

    [self updateLayouts];
}

- (void)removeItemAtIndex:(NSInteger)index {
    if (self.segmentItems.count <= 0) {
        return;
    }
    
    if (index != NSNotFound && index < self.segmentItems.count) {
        [self.segmentItems removeObjectAtIndex:index];
    } else {
        [self.segmentItems removeLastObject];
    }

    if (self.selectedSegmentIndex >= self.segmentItems.count) {
        self.selectedSegmentIndex = self.segmentItems.count - 1;
    }

    [self updateLayouts];
}

- (void)replaceItem:(SegmentModel *)item atIndex:(NSInteger)index {
    if (self.segmentItems.count <= 0) {
        return;
    }

    if (index >= self.segmentItems.count) {
        return;
    }

    self.segmentItems[index] = item;
    self.reloadItems = @[[NSIndexPath indexPathForItem:index inSection:0]].mutableCopy;
    [self updateLayouts];
    self.reloadItems = nil;
}

- (void)deselect {
    self.selectedSegmentIndex = -1;
}


#pragma mark - <UICollectionViewDataSource>
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.segmentItems.count;
}

- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView
                           cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"하하하");
    if (collectionView != self.collectionView) {
        BackgroundCollectionViewCell *cell =
        [collectionView dequeueReusableCellWithReuseIdentifier:@"BackgroundCollectionViewCell"
                                                  forIndexPath:indexPath];
        [cell configureStyle:self.preset isSeparatorVisible:indexPath.row != 0];
        return cell;
    }
    
    SegmentCollectionViewCell *cell;
    SegmentModel *segmentItem = self.segmentItems[indexPath.row];

    cell =
    [collectionView dequeueReusableCellWithReuseIdentifier:@"SegmentCollectionViewCell"
                                              forIndexPath:indexPath];
    
    [cell configure:segmentItem style:self.preset];

    if (self.selectedSegmentIndex >= 0 &&
        self.selectedSegmentIndex < self.segmentItems.count &&
        indexPath.row == self.selectedSegmentIndex)  {
        
        cell.selected = indexPath.row == self.selectedSegmentIndex;
        [collectionView selectItemAtIndexPath:indexPath
                                     animated:NO
                               scrollPosition:UICollectionViewScrollPositionCenteredHorizontally];
    }

    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView
       willDisplayCell:(SegmentCollectionViewCell *)cell
    forItemAtIndexPath:(NSIndexPath *)indexPath {

    if (collectionView != self.collectionView) {
        return;
    }
    
    if ([cell isKindOfClass:[SegmentCollectionViewCell class]] == YES) {
        [cell loadImageIfNeeded];
    }
}

- (void)collectionView:(UICollectionView *)collectionView
  didEndDisplayingCell:(SegmentCollectionViewCell *)cell
    forItemAtIndexPath:(NSIndexPath *)indexPath {
    
    if (collectionView != self.collectionView) {
        return;
    }
    if ([cell isKindOfClass:[SegmentCollectionViewCell class]] == YES) {
        [cell cancelImageDownloadIfNeeded];
    }
}


#pragma mark - <UICollectionViewDelegate>
- (void)collectionView:(UICollectionView *)collectionView
didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    self.selectedSegmentIndex = indexPath.row;
}

- (BOOL)collectionView:(UICollectionView *)collectionView
shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    return collectionView == self.collectionView;
}


#pragma mark - private
- (void)updateCollectionViewSizeWithItemSize:(CGSize)itemSize {
    
    self.collectionViewFlow.minimumLineSpacing = self.preset.segmentSpacing;
    self.collectionViewFlow.itemSize = itemSize;
    
    self.collectionViewFlow2.minimumLineSpacing = self.preset.segmentSpacing;
    self.collectionViewFlow2.itemSize = itemSize;

    self.collectionView.collectionViewLayout = self.collectionViewFlow;
    self.collectionViewBackground.collectionViewLayout = self.collectionViewFlow2;

    if (self.reloadItems != nil) {
        [self.collectionView reloadItemsAtIndexPaths:self.reloadItems];
    } else {
        [self.collectionView reloadData];
        [self.collectionViewBackground reloadData];
    }
}

- (void)updateSelectedBackgroundViewFrameWithItemSize:(CGSize)itemSize {
    CGFloat offset = self.preset.selectedSegmentItemOffset;

    CGSize backgroundSize = CGSizeMake(itemSize.width, itemSize.height - 2*offset);
    CGFloat backgroundYPosition = 0.0 + offset;

    
    if (SelectedSegmentSizeIsMaxHeight(self.preset.selectedSegmentItemSizeType) == NO) {
        CGFloat height = self.preset.selectedSegmentItemSizeType.fixedHeight;
        backgroundSize = CGSizeMake(itemSize.width - 2.0 * offset, height - 2.0 * offset);
        if (self.preset.selectedSegmentItemSizeType.isFixedHeightPositionTop == NO) {
            backgroundYPosition = itemSize.height - height + offset;
        } else {
            backgroundYPosition = 0 + offset;
        }
    }
    

    if (self.selectedSegmentIndex == -1) {
        self.selectedBackgroundView.hidden = YES;
        self.selectedBackgroundView.frame =
        CGRectMake(offset,
                   backgroundYPosition + offset,
                   backgroundSize.width,
                   backgroundSize.height);
    } else {
        self.selectedBackgroundView.hidden = NO;
        CGFloat selectedItemXPosition =
        self.selectedSegmentIndex * (itemSize.width + self.preset.segmentSpacing);

        
        if (self.selectedSegmentIndex == 0) {
            selectedItemXPosition += offset;
            backgroundSize.width -= offset;
        } else if (self.selectedSegmentIndex == (self.segmentItems.count - 1)) {
            backgroundSize.width -= offset;
        }
        
        CGPoint selectedItemPosition = CGPointMake(selectedItemXPosition, backgroundYPosition);
        
        self.selectedBackgroundView.frame = CGRectMake(selectedItemPosition.x, selectedItemPosition.y, backgroundSize.width, backgroundSize.height);
    }
}

/// Layout-Driven UI 😎
- (void)updateLayouts {
    [self setNeedsLayout];
    
    CGFloat duration = 0.0f;
    if (self.canCollectionViewUpdateLayout == NO) {
        duration = 0.5;
    }
    
    UIViewPropertyAnimator *layoutAnimator =
    [[UIViewPropertyAnimator alloc] initWithDuration:duration
                                        dampingRatio:1.3
                                          animations:^{
        [self layoutIfNeeded];
    }];
    
    [layoutAnimator startAnimation];
}

- (void)setPreset:(RESegmentedControlPreset *)preset {
    _preset = preset;
    
    self.collectionView.clipsToBounds = self.preset.segmentClipsToBounds;
    self.collectionViewBackground.clipsToBounds = self.preset.segmentClipsToBounds;
    self.collectionView.layer.cornerRadius = self.preset.segmentCornerRadius;
    self.collectionViewBackground.layer.cornerRadius = self.preset.segmentCornerRadius;
    self.collectionView.layer.borderColor = self.preset.segmentBorderColor;
    self.collectionView.layer.borderWidth = self.preset.segmentBorderWidth;
    self.selectedBackgroundView.backgroundColor = self.preset.selectedSegmentItemColor;
    self.selectedBackgroundView.layer.cornerRadius = self.preset.selectedSegmentItemCornerRadius;
    self.selectedBackgroundView.layer.borderWidth = self.preset.selectedSegmentItemBorderWidth;
    self.selectedBackgroundView.layer.borderColor = self.preset.selectedSegmentItemBoderColor;
    
    if (self.preset.selectedSegmentItemShadowHidden == NO) {
        self.selectedBackgroundView.layer.shadowColor = self.preset.selectedSegmentItemShadowColor;
        self.selectedBackgroundView.layer.shadowOpacity = self.preset.selectedSegmentItemShadowOpacity;
        self.selectedBackgroundView.layer.shadowOffset = self.preset.selectedSegmentItemShadowOffset;
        self.selectedBackgroundView.layer.shadowRadius = self.preset.selectedSegmentItemShadowRadius;
        self.selectedBackgroundView.layer.shadowPath = self.preset.selectedSegmentItemShadowPath;
    }
        
    [self.collectionView reloadData];
    [self.collectionViewBackground reloadData];
}

@end
