//
//  ItemForTableView.m
//  CustomizingNavigationBar
//
//  Created by Kwan Hyun Son on 13/12/2018.
//  Copyright © 2018 Mulgrim Inc. All rights reserved.
//

#import "ItemsForTableView.h"
#import "Item.h"

@implementation ItemsForTableView

+ (instancetype)sharedItems {
    static ItemsForTableView *sharedItems = nil;
    
    if(!sharedItems) {
        sharedItems =  [[self alloc] initPrivate];
    }
    
    return sharedItems;
}

/// 진짜 초기화 메서드, 최초 1회만 호출될 것이다.
- (instancetype)initPrivate {
    self = [super init];
    if(self) {
        Item *item1 = [[Item alloc] initWithText:@"Basic Layout Example" detailText:@"..."];
        Item *item2 = [[Item alloc] initWithText:@"Selecting, Adding, Removing" detailText:@"..."];
        Item *item3 = [[Item alloc] initWithText:@"Presets Example" detailText:@"..."];
        _allItems = [NSMutableArray arrayWithObjects:item1, item2, item3, nil];
    }
    return self;
}

@end
