//
//  ShadowStylable.h
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/13.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol ShadowStylable <NSObject>
@optional
@required

- (CGColorRef __nullable)color;
- (void)setColor:(CGColorRef __nullable)color;

- (CGFloat)opacity;
- (void)setOpacity:(CGFloat)opacity;

- (CGSize)offset;
- (void)setOffset:(CGSize)offset;

- (CGFloat)radius;
- (void)setRadius:(CGFloat)radius;

- (CGPathRef __nullable)path;
- (void)setPath:(CGPathRef __nullable)path;

@end

NS_ASSUME_NONNULL_END
