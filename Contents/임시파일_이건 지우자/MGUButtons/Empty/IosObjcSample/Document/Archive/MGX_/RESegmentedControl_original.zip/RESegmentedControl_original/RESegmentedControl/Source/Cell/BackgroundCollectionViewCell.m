//
//  BackgroundCollectionViewCell.m
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/13.
//

#import "BackgroundCollectionViewCell.h"
#import "RESegmentedControlPreset.h"

@interface BackgroundCollectionViewCell ()
@property (nonatomic, strong, nullable) RESegmentedControlPreset *style;
@property (nonatomic, assign) BOOL isSeparatorVisible; // 디폴트 NO
@end

@implementation BackgroundCollectionViewCell

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self commonInit];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)coder {
    self = [super initWithCoder:coder];
    if (self) {
        [self commonInit];
    }
    return self;
}

- (void)prepareForReuse {
    [super prepareForReuse];
    self.separatorView.hidden = YES;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}


#pragma mark - 생성 & 소멸
- (void)commonInit {
    _isSeparatorVisible = NO;
}

- (void)configureStyle:(RESegmentedControlPreset *)style
    isSeparatorVisible:(BOOL)isSeparatorVisible {
    self.isSeparatorVisible = isSeparatorVisible;
    self.style = style;
    
}

- (void)setStyle:(RESegmentedControlPreset *)style {
    _style = style;
    [self configUI];
}

- (void)configUI {
    if (self.style == nil) {
        return;
    }

    self.bgView.backgroundColor = self.style.backgroundColor;
    self.bgView.layer.cornerRadius = self.style.segmentItemCornerRadius;
    self.bgView.layer.borderColor = self.style.segmentItemBorderColor;
    self.bgView.layer.borderWidth = self.style.segmentItemBorderWidth;
    self.contentView.layer.masksToBounds = YES;
    
    if (self.style.segmentItemShadowHidden == NO) {
        self.layer.shadowColor = self.style.segmentItemShadowColor;
        self.layer.shadowOpacity = self.style.segmentItemShadowOpacity;
        self.layer.shadowOffset = self.style.segmentItemShadowOffset;
        self.layer.shadowRadius = self.style.segmentItemShadowRadius;
        self.layer.shadowPath = self.style.segmentItemShadowPath;
    }
    
    if (self.style.segmentItemSeparatorHidden == NO) {
        self.separatorViewWidthLC.constant = self.style.segmentItemSeparatorWidth;
        self.separatorViewTopLC.constant = self.style.segmentItemSeparatorOffset;
        self.separatorViewBottomLC.constant = self.style.segmentItemSeparatorOffset;
        self.separatorViewLeadingLC.constant = -(self.style.segmentItemSeparatorWidth / 2.0);
        self.separatorView.backgroundColor = self.style.segmentItemSeparatorColor;
    }
    
    self.separatorView.hidden = !self.isSeparatorVisible || self.style.segmentItemSeparatorHidden == YES;
}

@end
