//
//  NSData+HexEncodedString.h
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/14.
//
//! NSData는 description 메소드에서 출력하는 것과 유사한 16진수 문자열로 표시될 수 있다.

#import <UIKit/UIKit.h>
// https://stackoverflow.com/a/40089462
// https://riptutorial.com/ios/example/18979/converting-nsdata-to-hex-string
// https://stackoverflow.com/questions/1305225/best-way-to-serialize-an-nsdata-into-a-hexadeximal-string
// https://stackoverflow.com/questions/16521164/how-can-i-convert-nsdata-to-hex-string
// https://stackoverflow.com/questions/7520615/how-to-convert-an-nsdata-into-an-nsstring-hex-string

NS_ASSUME_NONNULL_BEGIN

@interface NSData (HexEncodedString)

- (NSString *)hexEncodedString;

@end

NS_ASSUME_NONNULL_END
//
// 스위프트 버전.
//extension Data {
//    func hexEncodedString() -> String {
//        return map { String(format: "%02hhx", $0) }.joined()
//    }
//}

// 또는 이것.
//extension NSData {
//    func hexString() -> String {
//        return UnsafeBufferPointer<UInt8>(start: UnsafePointer<UInt8>(bytes), count: length)
//            .reduce("") { $0 + String(format: "%02x", $1) }
//    }
//
//}
