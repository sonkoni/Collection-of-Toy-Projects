//
//  SegmentedControlPresettable.h
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/13.
//

#import "SegmentStylable.h"
#import "SegmentItemStylable.h.h"

NS_ASSUME_NONNULL_BEGIN

@protocol SegmentedControlPresettable <NSObject>
@optional
@required
- (id <SegmentStylable>)segmentStyle;
- (void)setSegmentStyle:(id <SegmentStylable>)segmentStyle;

- (id <SegmentItemStylable>)segmentItemStyle;
- (void)setSegmentItemStyle:(id <SegmentItemStylable>)segmentItemStyle;

- (id <SegmentSelectedItemStylable>)segmentSelectedItemStyle;
- (void)setSegmentSelectedItemStyle:(id <SegmentSelectedItemStylable>)segmentSelectedItemStyle;


// -MARK: SegmentStylable

// -MARK: SegmentItemStylable

// -MARK: SegmentSelectedItemStylable
@end

NS_ASSUME_NONNULL_END
