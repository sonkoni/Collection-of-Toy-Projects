//
//  NSFileManager+Extention.h
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/13.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSFileManager (Extention)

- (NSURL * _Nullable)saveImage:(NSData *)data filename:(NSString *)filename;
- (NSURL * _Nullable)save:(NSData *)data filename:(NSString *)filename directory:(NSURL *)directory;
- (NSData * _Nullable)imageDataFilename:(NSString *)filename;
- (NSData * _Nullable)dataFromDirectory:(NSURL *)directory filename:(NSString *)filename;


- (void)removeImagesDirectory;

@end

NS_ASSUME_NONNULL_END
