//
//  SeparatorStylable.h
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/13.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol SeparatorStylable <NSObject>
@optional
@required

- (UIColor *)color;
- (void)setColor:(UIColor *)color;

- (CGSize)width;
- (void)setWidth:(CGSize)width;

- (CGSize)offset;
- (void)setOffset:(CGSize)offset;

@end

NS_ASSUME_NONNULL_END
