//
//  MGRSegment.m
//  MGRButtons
//
//  Created by Kwan Hyun Son on 13/08/2019.
//  Copyright © 2019 Mulgrim Inc. All rights reserved.
//

#import "MGXSegment.h"
#import "MGXSegmentConfiguration.h"
#import "MGXSegmentModel.h"
#import "ImageDownloader.h"
#import "UIView+AutoLayout.h"

extern CGFloat MGXSegmentedControlMinimumScale;
extern CGFloat MGXSegmentedControlHalfShinkRatio;

static CGFloat const kMinimumSegmentWidth = 64.0f; //! 각 세그먼트의 최소의 폭은 64.0으로 확보한다.

@interface MGXSegment ()
@property (nonatomic, strong) UIView *containerView;
@property (nonatomic, strong) UIStackView *stackView;
@property (nonatomic, strong) MGXSegmentModel *model;
@property (nonatomic, strong) ImageDownloader *imageDownload; // lazy
@end

@implementation MGXSegment

//! 인수로 주어진 size에 가장 적합한 size를 계산하고 반환하도록 뷰에 요청한다. Api:UIKit/UIView/- sizeThatFits: 참고.
- (CGSize)sizeThatFits:(CGSize)size {
    //CGSize sizeThatFits = [self.titleView sizeThatFits:size];
    CGSize sizeThatFits = [self.titleLabel sizeThatFits:size];
    return CGSizeMake(MAX(sizeThatFits.width * 1.4f, kMinimumSegmentWidth), sizeThatFits.height);
    //
    // 이 메서드의 디폴트의 구현은, view의 기존의 size를 돌려준다.
    // 이 메서드는, 리시버의 사이즈를 변경하지 않는다.
    // MGRSegmentTextRenderView의 sizeThatFits:를 이용한며, 본 메서드는 MGRSegmentedControl의 sizeThatFits: 메서드에서 이용된다.
}

- (NSString *)accessibilityLabel {
    return self.titleLabel.text;
    //return self.titleView.text;
    //
    // voice over 같은 앱에게 self(세그먼트)에게 버턴의 이름을 알려준다.
    // 버튼이나 스위치 같은 정보를 포함해서는 안된다. 이것은 self.accessibilityTraits = super.accessibilityTraits | UIAccessibilityTraitButton; 으로 알려준다.
}


#pragma mark - 생성 & 소멸
- (instancetype)initWithSegmentModel:(MGXSegmentModel *)model {
    self = [super initWithFrame:CGRectMake(0.0, 0.0, 50.0, 50.0)];
    if (self) {
        _model = model;
        [self commonInit];
    }
    return self;
}

+ (instancetype)segmentWithSegmentModel:(MGXSegmentModel *)model {
    return [[MGXSegment alloc] initWithSegmentModel:model];
}

- (void)commonInit {
    // 다른 앱(voice over 같은)에서의 접근성을 의미한다. 시각 장애인에게 self 객체가 버튼이라는 것을 알려준다.
    self.isAccessibilityElement = YES;
    //The accessibility element should be treated as a button.
    self.accessibilityTraits = super.accessibilityTraits | UIAccessibilityTraitButton;
    self.userInteractionEnabled = NO; // userInteractionEnabled을 NO로 하는 이유는 인디케이터가 밑에 있기 때문이다.
    // 전체 세그먼트 컨트롤 바로 위에 인디케이터가 존재하고 그 위 세그먼트들과 각 라벨이 존재한다.
    
    MGXSegmentConfiguration *configuration = [MGXSegmentConfiguration defaultConfiguration];
    
    _font                 = configuration.titleFont;
    _selectedFont         = configuration.selectedTitleFont;
    _titleColor            = configuration.titleColor;
    _selectedTitleColor    = configuration.selectedTitleColor;
    _isSelectedTextGlowON = configuration.isSelectedTextGlowON;
    _imageTintColor         = configuration.imageTintColor;
    _selectedImageTintColor = configuration.selectedImageTintColor;
    
    _containerView = [UIView new];
    self.containerView.backgroundColor = [UIColor clearColor];
    [self addSubview:self.containerView];
    self.containerView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.containerView.topAnchor constraintEqualToAnchor:self.topAnchor constant:5.0].active = YES;
    [self.containerView.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:5.0].active = YES;
    [self.trailingAnchor constraintEqualToAnchor:self.containerView.trailingAnchor constant:5.0].active = YES;
    [self.bottomAnchor constraintEqualToAnchor:self.containerView.bottomAnchor constant:5.0].active = YES;
    
    _stackViewSpacing = 0.0;
    _stackViewAxis = UILayoutConstraintAxisVertical;
    _stackView = self.stackView = [[UIStackView alloc] init];
    self.stackView.axis = UILayoutConstraintAxisVertical;
    self.stackView.spacing = self.stackViewSpacing;
    self.stackView.distribution = UIStackViewDistributionFill;
    self.stackView.alignment = UIStackViewAlignmentCenter;
    [self.containerView addSubview:self.stackView];
    [self.stackView mgrPinCenterToSuperviewCenterWithInner];
    
    _imageView = [UIImageView new];
    self.imageView.contentMode = UIViewContentModeScaleAspectFit;
    [self.stackView addArrangedSubview:self.imageView];
    [self.imageView.widthAnchor constraintEqualToAnchor:self.imageView.heightAnchor].active = YES;
    _imageViewHeightLayoutConstraint =
    [self.imageView.heightAnchor constraintEqualToConstant:configuration.imageViewSize];
    //! 현재 self size.height 0.0이므로 높이 15.0을 잡지 못해 AutoLayout 버그 메시지가 나온다. 최초 frame size를 50.0 50.0으로 주자.
    self.imageViewHeightLayoutConstraint.active = YES;
    
    _titleLabel = [UILabel new];
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.layer.shadowColor = self.selectedTitleColor.CGColor;
    self.titleLabel.layer.shadowRadius = 1.0f;
    self.titleLabel.layer.shadowOpacity = 0.0; // 이걸로 키자.
    self.titleLabel.layer.shadowOffset = CGSizeZero;
    [self.stackView addArrangedSubview:self.titleLabel];
    self.stackView.axis = UILayoutConstraintAxisVertical;
    [self initializeTitle];
    [self initializeImage];
}

- (void)initializeTitle {
    NSString *title = self.model.title;
    if (title != nil) {
        self.titleLabel.text = title;
        self.titleLabel.hidden = NO;
    } else {
        self.titleLabel.hidden = YES;
    }
}

- (void)initializeImage {
    if (self.model.imageUrl != nil) {
        __weak __typeof(self)weakSelf = self;
        [self.imageDownload downloadImageUrl:self.model.imageUrl
                                completion:^(UIImage * _Nonnull image,
                                             NSURL * _Nonnull url,
                                             NSError * _Nonnull error) {
            __strong __typeof(weakSelf) self = weakSelf;
            if (image == nil) {
                return;
            }
                
            if ([self.model.imageUrl isEqual:url] == NO) {
                return;
            }
                
            self.imageView.image = [image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
        }];

        return;
    }
    
    NSString *imageName = self.model.imageName;
    if (imageName == nil) {
        self.imageView.hidden = YES;
    } else {
        UIImage *image = [UIImage imageNamed:imageName];
        image = [image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
        if (image == nil) {
            self.imageView.hidden = YES;
        } else {
            self.imageView.image = image;
            self.imageView.hidden = NO;
        }
    }
}


#pragma mark - 세터 & 게터
- (ImageDownloader *)imageDownload { //! lazy
    if (_imageDownload == nil) {
        _imageDownload = [ImageDownloader new];
    }
    return _imageDownload;
}

- (void)setSelected:(BOOL)selected {
    _selected = selected;
    
    //! 시각 장애인에게 알려줄 수 있다.
    if (selected) {
        self.accessibilityTraits = self.accessibilityTraits | UIAccessibilityTraitSelected;
    } else {
        self.accessibilityTraits = self.accessibilityTraits & ~UIAccessibilityTraitSelected;
    }
}

- (void)setSegmentState:(MGXSegmentState)segmentState {
    _segmentState = segmentState;
    if (segmentState == MGXSegmentStateNoIndicator) { // 평범한 상태
        self.titleLabel.textColor = self.titleColor;
        self.titleLabel.font = self.font;
        self.imageView.tintColor = self.imageTintColor;
        self.titleLabel.layer.shadowOpacity = 0.0f;
    } else {
        self.titleLabel.textColor = self.selectedTitleColor;
        self.titleLabel.font = self.selectedFont;
        self.imageView.tintColor = self.selectedImageTintColor;
        if (self.isSelectedTextGlowON == YES) {
            self.titleLabel.layer.shadowOpacity = 1.0f;
        } else {
            self.titleLabel.layer.shadowOpacity = 0.0f;
        }
    }
}

- (void)setStackViewAxis:(UILayoutConstraintAxis)stackViewAxis {
    _stackViewAxis = stackViewAxis;
    self.stackView.axis = stackViewAxis;
}

- (void)setStackViewSpacing:(CGFloat)stackViewSpacing {
    _stackViewSpacing = stackViewSpacing;
    self.stackView.spacing = stackViewSpacing;
}

- (void)setSelectedTitleColor:(UIColor *)selectedTextColor {
    _selectedTitleColor = selectedTextColor;
    self.titleLabel.layer.shadowColor = selectedTextColor.CGColor;
}


#pragma mark - Action
- (void)setHighlight:(BOOL)highlight {
    if (_highlight == highlight) {
        return;
    }
    
    _highlight = highlight;
    
    
    CGFloat highlightOpacity = 0.2;
    CABasicAnimation *opacityAnimation = [CABasicAnimation animationWithKeyPath:@"opacity"];
    if (self.highlight == YES) {
        if (self.layer.presentationLayer != nil) {
            CGFloat opacity  = self.layer.presentationLayer.opacity;
            [CATransaction begin];
            [CATransaction setDisableActions:YES];
            self.layer.opacity = opacity; //! 이렇게 잡아줘야 깜빡거림을 없앨 수 있다.
            [CATransaction commit];
            
        } else {
            opacityAnimation.fromValue = @(1.0);
        }
        
        opacityAnimation.toValue   = @(highlightOpacity);
    } else {
        if (self.layer.presentationLayer != nil) {
            CGFloat opacity  = self.layer.presentationLayer.opacity;
            [CATransaction begin];
            [CATransaction setDisableActions:YES];
            self.layer.opacity = opacity; //! 이렇게 잡아줘야 깜빡거림을 없앨 수 있다.
            [CATransaction commit];
        } else {
            opacityAnimation.fromValue = @(highlightOpacity);
        }
        
        opacityAnimation.toValue   = @(1.0);
    }
    
    opacityAnimation.duration  = 0.3f;
    opacityAnimation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
    opacityAnimation.fillMode       = kCAFillModeForwards;
    opacityAnimation.removedOnCompletion = NO;
    
    [CATransaction setCompletionBlock:^{
        self.layer.opacity = 1.0f;
    }];
    
    // key 를 반드시 동일한 걸로 입력하라. nil 안됨.
    [self.layer addAnimation:opacityAnimation forKey:@"OpacityAnimationKey"];
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    
    [CATransaction commit];

}

- (void)setShrink:(BOOL)shrink {
    if (_shrink == shrink) {
        return;
    }
    
    _shrink = shrink;
    
    CABasicAnimation *scaleAnimation = [CABasicAnimation animationWithKeyPath:@"transform"];
    if (self.shrink == YES) {
        if (self.layer.presentationLayer != nil) {
            CATransform3D transform  = self.layer.presentationLayer.transform;
            scaleAnimation.fromValue = @(transform); // <- 현재 스케일에 해당한다.
            
            [CATransaction begin];
            [CATransaction setDisableActions:YES];
            self.layer.transform = transform; //! 이렇게 잡아줘야 깜빡거림을 없앨 수 있다.
            [CATransaction commit];
            
        } else {
            scaleAnimation.fromValue = @(CATransform3DIdentity);
        }
        scaleAnimation.toValue   = @([self targetShrinkTransform3D]);
    } else {
        if (self.layer.presentationLayer != nil) {
            CATransform3D transform  = self.layer.presentationLayer.transform;
            scaleAnimation.fromValue = @(transform); // <- 현재 스케일에 해당한다.
            [CATransaction begin];
            [CATransaction setDisableActions:YES];
            self.layer.transform = transform; //! 이렇게 잡아줘야 깜빡거림을 없앨 수 있다.
            [CATransaction commit];
        } else {
            scaleAnimation.fromValue   = @([self targetShrinkTransform3D]);
        }
        
        scaleAnimation.toValue   = @(CATransform3DIdentity);
    }
    
    scaleAnimation.duration  = 0.2f;
    scaleAnimation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
    scaleAnimation.fillMode          = kCAFillModeForwards;
    scaleAnimation.removedOnCompletion = NO;
    
    [CATransaction setCompletionBlock:^{
        self.layer.transform = CATransform3DIdentity;
    }];
    
    // key 를 반드시 동일한 걸로 입력하라. nil 안됨.
    [self.layer addAnimation:scaleAnimation forKey:@"ScaleAnimationKey"];
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    
    [CATransaction commit];
}


#pragma mark - Helper
//! 제일 왼쪽에 있을 경우, 왼쪽으로 더 움직여주고, 제일 오른쪽에 있을 경우, 오른쪽으로 더 움직여준다.
- (CATransform3D)targetShrinkTransform3D {
    //! Scale을 변화시켜도 bounds는 유지된다. 이를 이용하자.
    CGFloat bottom = self.bounds.size.height * MGXSegmentedControlHalfShinkRatio; // 아래에서 줄어든 길이
    CGFloat side = self.bounds.size.width * MGXSegmentedControlHalfShinkRatio; // 옆에서 줄어든 길이
    CGFloat shiftValue = ABS(side - bottom);
    
    UIStackView *mySuperView = (UIStackView *)self.superview;
    NSArray <MGXSegment *>*segments = mySuperView.arrangedSubviews;
    
    CATransform3D transform = CATransform3DIdentity;
    if (self == segments.firstObject) {
        transform = CATransform3DTranslate(CATransform3DIdentity, -shiftValue, 0.0, 0.0);
    } else if (self == segments.lastObject) {
        transform = CATransform3DTranslate(CATransform3DIdentity, +shiftValue, 0.0, 0.0);
    }
    
    return CATransform3DScale(transform, MGXSegmentedControlMinimumScale, MGXSegmentedControlMinimumScale, 1.0);
}

@end
