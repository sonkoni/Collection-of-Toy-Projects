//
//  ViewController2.m
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/13.
//

#import "ViewController2.h"
#import "RESegmentedControl.h"

@interface ViewController2 ()
@property (nonatomic, strong) NSArray <NSString *>*items;
@property (weak, nonatomic) IBOutlet RESegmentedControl *segment;
@property (weak, nonatomic) IBOutlet UILabel *selectedIndexLabel;
@end

@implementation ViewController2

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"Actions Example";
    
    _items = @[@"Item 1", @"Item 2"];
    
    NSArray <SegmentModel *>*segmentItems =
    @[[[SegmentModel alloc] initWithTitle:@"Item 1"],
      [[SegmentModel alloc] initWithTitle:@"Item 2"]];
    
    RESegmentedControlPreset *configuration = [RESegmentedControlPreset defaultConfiguration];
    configuration.selectedSegmentItemColor =
    [UIColor colorWithRed:0.9843137255 green:0.7568627451 blue:0.03529411765 alpha:1.0];
    configuration.segmentItemBorderWidth = 1.0f;
    configuration.segmentItemBorderColor =
    [UIColor colorWithRed:0.9333333333 green:0.9333333333 blue:0.9333333333 alpha:1.0].CGColor;
    configuration.textFont = [UIFont systemFontOfSize:11.0 weight:UIFontWeightBold];
    
    [self.segment configureSegmentItems:segmentItems
                                 preset:configuration
                          selectedIndex:0];
    
}

- (IBAction)segmentValueChanged:(RESegmentedControl *)sender {
    self.selectedIndexLabel.text =
    [NSString stringWithFormat:@"selected segment index: %d", (int)sender.selectedSegmentIndex];
    NSLog(@"selectedIndexLabel.text ==> %@", self.selectedIndexLabel.text);
}

- (IBAction)addItem:(id)sender {
    NSString *title = [NSString stringWithFormat:@"Item %d", (int)(self.segment.segmentItemsCount + 1)];
    SegmentModel *model =
    [[SegmentModel alloc] initWithTitle:title
                              imageName:nil
                                 bundle:nil];
    [self.segment addItem:model atIndex:NSNotFound];
}

- (IBAction)removeFirstItem:(id)sender {
    [self.segment removeItemAtIndex:0];
}

- (IBAction)removeItem:(id)sender {
    [self.segment removeItemAtIndex:NSNotFound];
}

- (IBAction)selectLastItem:(id)sender {
    self.segment.selectedSegmentIndex = self.segment.segmentItemsCount - 1;
}

- (IBAction)deselectItem:(id)sender {
    [self.segment deselect];
}

- (IBAction)replaceItem:(id)sender {
    SegmentModel *model =
    [[SegmentModel alloc] initWithTitle:@"Replaced Item"];
    [self.segment replaceItem:model atIndex:0];
}

@end
