//
//  NSURL+Filename.h
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/14.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSURL (Filename)

/// Hashed filename from remote url path
- (NSString *)filename;

@end

NS_ASSUME_NONNULL_END
