//
//  MGRSegmentedControl.m
//  MGRButtons
//
//  Created by Kwan Hyun Son on 13/08/2019.
//  Copyright © 2019 Mulgrim Inc. All rights reserved.
//

#import "MGXSegmentedControl.h"
#import "MGXSegmentConfiguration.h"
#import "MGXSegment.h"
#import "MGXSegmentIndicator.h"
#import "UIView+AutoLayout.h"
#import "MGRGeometryHelper.h"

CGFloat MGXSegmentedControlMinimumScale = 0.94999999999999996;
CGFloat MGXSegmentedControlHalfShinkRatio = (1 - 0.94999999999999996) / 2.0; // 세로로 줄어든 양에 대한 반.

// nomal, selected, normal Highlighted, selected Shrink
@interface MGXSegmentedControl ()
@property (nonatomic) UIView *fullContainerView;
@property (nonatomic) NSArray<UIView *> *segmentBackUpViews;
@property (nonatomic) UIView *separatorContainerView;
@property (nonatomic) NSArray<UIView *> *separatorViews;
@property (nonatomic) MGXSegmentIndicator *segmentIndicator;
@property (nonatomic) UIStackView *segmentsStackView;
@property (nonatomic) NSArray<MGXSegment *> *segments;
@property (nonatomic) BOOL beginTrackingOnIndicator;
@property (nonatomic) NSInteger currentTouchIndex;
@end

@implementation MGXSegmentedControl
@dynamic borderWidth;
@dynamic borderColor;
@dynamic numberOfSegments;
@dynamic indicatorBackgroundColor;
@dynamic indicatorGradientTopColor;
@dynamic indicatorGradientBottomColor;
@dynamic indicatorBorderColor;
@dynamic indicatorBorderWidth;
@dynamic drawsIndicatorGradientBackground;
@dynamic indicatorShadowHidden;
@dynamic isIndicatorBarStyle;

+ (Class)layerClass {
    return [CAGradientLayer class];
}

- (instancetype)init {
    MGXSegmentModel *model1 = [MGXSegmentModel segmentModelWithTitle:@"Title1"];
    MGXSegmentModel *model2 = [MGXSegmentModel segmentModelWithTitle:@"Title2"];
    return [self initWithTitles:@[model1, model2] selecedtitle:nil configuration:nil];
}

//! 인수로 주어진 size에 가장 적합한 size를 계산하고 반환하도록 뷰에 요청한다. Api:UIKit/UIView/- sizeThatFits: 참고.
- (CGSize)sizeThatFits:(CGSize)size {
    CGFloat maxSegmentWidth = 0.0f;
    for (MGXSegment *segment in self.segments) {
        CGFloat segmentWidth = [segment sizeThatFits:size].width; // MGRSegment도 sizeThatFits:을 재정의하였다.
        if (segmentWidth > maxSegmentWidth) {
            maxSegmentWidth = segmentWidth;
        }
    }
    return CGSizeMake(maxSegmentWidth * self.segments.count, 32.0f);
    //
    // 이 메서드의 디폴트의 구현은, view의 기존의 size를 돌려준다.
    // 이 메서드는, 리시버의 사이즈를 변경하지 않는다.
    // MGRSegment도 sizeThatFits:을 재정의하였으며, MGRSegment의 sizeThatFits: 에서는 MGRSegmentTextRenderView의 sizeThatFits:을 호출한다.
    // 결과적으로 가장 큰 MGRSegmentTextRenderView의 크기에 1.4 배가 된 width를 단윈 width 로 사용한다.
}

- (CGSize)intrinsicContentSize {
    return [self sizeThatFits:self.bounds.size];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    [self.fullContainerView layoutIfNeeded]; // 컨테이너로 싸버렸으므로, 반응이 조금 느릴 수 있기 때문이다.
    
    //! FIXME: 스페이싱은 조금 더 다듬어야하마.
    CGRect separatorFrame = CGRectMake(0.0, 0.0, 1.0, self.bounds.size.height * self.separatorHeightRatio);
    NSInteger totalCount = self.segments.count;
    CGFloat unitWidth = (self.bounds.size.width / totalCount);
    
    for (NSInteger i = 0; i < totalCount - 1; i++) {
        CGPoint center = CGPointMake(unitWidth * (i + 1), self.bounds.size.height / 2.0);
        UIView *view = self.separatorViews[i];
        view.frame = separatorFrame;
        view.center = center;
    }

    for (int i = 0; i < self.segments.count; i++) {
        MGXSegment *segment = self.segments[i];
        
        segment.font = self.titleFont;
        segment.selectedFont      = self.selectedTitleFont;
        segment.titleColor         = self.titleColor;
        segment.selectedTitleColor = self.selectedTitleColor;
        segment.imageTintColor = self.imageTintColor;
        segment.selectedImageTintColor = self.selectedImageTintColor;
        
        if (self.selectedSegmentIndex == i) {
            [segment setSegmentState:MGXSegmentStateIndicator];
        } else {
            [segment setSegmentState:MGXSegmentStateNoIndicator];
        }
        
        
    }
    
    self.layer.cornerRadius = self.cornerRadiusPercent * (self.frame.size.height / 2.0);
    if (self.indicatorCornerRadiusAlwaysZero == YES) {
        self.segmentIndicator.cornerRadius = 0.0f;
    } else {
        self.segmentIndicator.cornerRadius =
        self.layer.cornerRadius * ((self.frame.size.height - (self.indicatorInset * 2)) / self.frame.size.height);
    }
    
    self.segmentIndicator.frame = [self indicatorFrameAtIndex:self.selectedSegmentIndex];
    [self hideAndShowSeparatorsAtIndex:self.selectedSegmentIndex];
    //
    // layoutSubviews는 drawRect: 보다 먼저 때려진다.
    // 그러나 layoutSubviews는 drawRect: 를 호출하지는 않는다. 마찬가지로 drawRect:는 layoutSubviews를 호출하지 않는다.
    // layoutSubviews <- setNeedsLayout 이고, drawRect: <- setNeedsDisplay
    // 오토레이아웃을 변경하거나 추가하면 호출되며 intrinsicContentSize를 호출하고, 그 다음 -> layoutSubviews를 호출한다.
    // setNeedsLayout은 intrinsicContentSize를 호출하지는 않고 바로 layoutSubviews를 호출한다.
}

- (void)drawRect:(CGRect)rect {
    if (self.drawsGradientBackground) {
        CAGradientLayer *gradientLayer = (CAGradientLayer *)self.layer;
        gradientLayer.colors = @[(__bridge id)[self.gradientTopColor CGColor],
                                 (__bridge id)[self.gradientBottomColor CGColor]];
    } else {
        self.layer.backgroundColor = [self.backgroundColor CGColor];
    }
    //
    // 아래는 디폴트 값이다. 그래디언트를 그릴 때에는 디폴트 값을 그대로 사용할 것이다.
    // gradientLayer.startPoint = CGPointMake(0.5,0.0);
    // gradientLayer.endPoint   = CGPointMake(0.5,1.0);
    // gradientLayer.type       = kCAGradientLayerAxial;
    // gradientLayer.frame      = rect;
    // 자신이 어딘가에 붙고 프레임이 zero가 아닐때, 발동된다.
    // setNeedsDisplay 메서드는 drawRect:를 강제로 호출한다.
    // layoutSubviews ~ setNeedsLayout 이고, drawRect: ~ setNeedsDisplay
}

- (void)setBackgroundColor:(UIColor *)backgroundColor {
    self.layer.backgroundColor = [backgroundColor CGColor];
}

- (UIColor *)backgroundColor {
    return [UIColor colorWithCGColor:self.layer.backgroundColor];
}

- (BOOL)beginTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event {
    CGPoint touchPoint = [touch locationInView:self];
    NSInteger nowTouchIndex = [self indexOfSegmentCloseToTouchPoint:touchPoint];

    NSInteger selectedSegmentIndex = self.selectedSegmentIndex;
    if (nowTouchIndex == selectedSegmentIndex) {
        _beginTrackingOnIndicator = YES;
        CGRect frame = [self indicatorMinimumScaleFrameAtIndex:nowTouchIndex];
        [self.segmentIndicator shrink:YES frame:frame];
        
        MGXSegment *segment = self.segments[self.selectedSegmentIndex];
        segment.shrink = YES;
        [self hideAndShowSeparatorsAtIndex:nowTouchIndex];
    } else {
        _beginTrackingOnIndicator = NO;
        MGXSegment *segment = self.segments[nowTouchIndex];
        segment.highlight = YES;
    }

    self.currentTouchIndex = nowTouchIndex;
    return [super beginTrackingWithTouch:touch withEvent:event];
}

- (BOOL)continueTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event {
    
    CGPoint touchPoint = [touch locationInView:self];
    NSInteger nowTouchIndex = [self indexOfSegmentCloseToTouchPoint:touchPoint];
    
    if (nowTouchIndex == self.currentTouchIndex ) {
        return [super continueTrackingWithTouch:touch withEvent:event];
    }
    
    if (self.beginTrackingOnIndicator == YES) { // 터치의 시작이 인디케이터일때...
        [self.segmentIndicator moveToFrame:[self indicatorMinimumScaleFrameAtIndex:nowTouchIndex] animated:YES];
        [self.segments enumerateObjectsUsingBlock:^(MGXSegment *segment, NSUInteger idx, BOOL *stop) {
            if (idx != nowTouchIndex) {
                segment.shrink = NO;
                segment.segmentState = MGXSegmentStateNoIndicator;
            } else {
                segment.shrink = YES;
                segment.segmentState = MGXSegmentStateIndicator;
            }
        }];
        [self hideAndShowSeparatorsAtIndex:nowTouchIndex];
    } else {
        [self.segments enumerateObjectsUsingBlock:^(MGXSegment *segment, NSUInteger idx, BOOL *stop) {
            if (idx != nowTouchIndex) {
                segment.highlight = NO;
            } else if (nowTouchIndex ==  self.selectedSegmentIndex) {
                segment.highlight = NO;
            } else {
                segment.highlight = YES;
            }
        }];
        
    }

    self.currentTouchIndex = nowTouchIndex;
    return [super continueTrackingWithTouch:touch withEvent:event];
}

- (void)endTrackingWithTouch:(UITouch *)touch withEvent:(UIEvent *)event {
    [super endTrackingWithTouch:touch withEvent:event];

    CGPoint touchPoint = [touch locationInView:self];
    NSInteger nowTouchIndex = [self indexOfSegmentCloseToTouchPoint:touchPoint];
    if (self.beginTrackingOnIndicator == YES) { // 터치의 시작이 인디케이터일때...
        [self touchUpState:nowTouchIndex];
        [self setSelectedSegmentIndex:nowTouchIndex animated:YES];
    } else {
        [self touchUpState:nowTouchIndex];
        if (nowTouchIndex != self.selectedSegmentIndex) {
            [self setSelectedSegmentIndex:nowTouchIndex animated:YES];
        }
    }
    [self hideAndShowSeparatorsAtIndex:nowTouchIndex];
    //[self hideAndShowSeparatorsAtIndex:NSNotFound];
    return;
}

- (void)cancelTrackingWithEvent:(UIEvent *)event {
    [self endTrackingWithTouch:nil withEvent:event];
}


#pragma mark - 생성 & 소멸
- (instancetype)initWithTitles:(NSArray <MGXSegmentModel *>*)segmentModels
                  selecedtitle:(NSString * _Nullable)selecedtitle
                 configuration:(MGXSegmentConfiguration * _Nullable)configuration {
    
    self = [super initWithFrame:CGRectZero];
    [self commonInit];
    if (self) {
        NSMutableArray *mutableSegmentsArr = [NSMutableArray array];
        NSMutableArray *mutableSeparatorsArr = [NSMutableArray array];
        
        NSInteger count = segmentModels.count;
        for (NSInteger i = 0; i < count; i++) {
            MGXSegmentModel *segmentModel = segmentModels[i];
            MGXSegment *segment = [[MGXSegment alloc] initWithSegmentModel:segmentModel];
            [self.segmentsStackView addArrangedSubview:segment];
            [mutableSegmentsArr addObject:segment];
            
            if (i != 0) {
                UIView *separatorView = [UIView new];
                [self.separatorContainerView addSubview:separatorView];
                [mutableSeparatorsArr addObject:separatorView];
            }
        }
        
        self.separatorViews = [NSArray arrayWithArray:mutableSeparatorsArr];
        self.segments = [NSArray arrayWithArray:mutableSegmentsArr];
        
        if (selecedtitle == nil) {
            [self setSelectedSegmentIndex:0];
        } else {
            for(int i = 0; i < segmentModels.count; i++) {
                if( [segmentModels[i].title isEqualToString:selecedtitle] ){
                    [self setSelectedSegmentIndex:i];
                }
            }
        }
        
        if ( (configuration != nil) && (configuration != [MGXSegmentConfiguration defaultConfiguration]) ) {
            self.configuration = configuration;
        }
    }
    return self;
}

- (void)commonInit {
    MGXSegmentConfiguration *configuration = [MGXSegmentConfiguration defaultConfiguration];
    _selectedTitleColor  = configuration.selectedTitleColor;
    _titleColor          = configuration.titleColor;
    _selectedImageTintColor  = configuration.selectedImageTintColor;
    _imageTintColor          = configuration.imageTintColor;
    _segmentContentsAxis = configuration.segmentContentsAxis;
    _segmentContentsSpacing = configuration.segmentContentsSpacing;
    
    _titleFont               = configuration.titleFont;
    _selectedTitleFont       = configuration.selectedTitleFont;
    
    _gradientTopColor        = configuration.gradientTopColor;
    _gradientBottomColor     = configuration.gradientBottomColor;
    
    _indicatorInset   = configuration.segmentIndicatorInset;
    _isSelectedTextGlowON    = configuration.isSelectedTextGlowON;
    _drawsGradientBackground = configuration.drawsGradientBackground;
    
    _cornerRadiusPercent               = configuration.cornerRadiusPercent;
    _indicatorCornerRadiusAlwaysZero = configuration.indicatorCornerRadiusAlwaysZero;
    
    _interItemSpacing  = configuration.interItemSpacing;
    _separatorColor = configuration.separatorColor;
    _separatorHeightRatio = configuration.separatorHeightRatio;
    
    self.backgroundColor     = configuration.backgroundColor;
    self.layer.borderColor   = configuration.borderColor.CGColor;
    self.layer.borderWidth   = configuration.borderWidth;
    self.layer.masksToBounds = YES;
    
    self.opaque = NO;
    
    _fullContainerView = [UIView new];
    self.fullContainerView.userInteractionEnabled = NO;
    self.fullContainerView.backgroundColor = [UIColor clearColor];
    [self addSubview:self.fullContainerView];
    [self.fullContainerView mgrPinEdgesToSuperviewEdges];
  
    _separatorContainerView = [UIView new];
    self.separatorContainerView.backgroundColor = [UIColor clearColor];
    [self.fullContainerView addSubview:self.separatorContainerView];
    [self.separatorContainerView mgrPinEdgesToSuperviewEdges];
    
    self.segmentIndicator = [[MGXSegmentIndicator alloc] initWithFrame:CGRectZero];
    self.drawsIndicatorGradientBackground = NO;  // 위의 segmentIndicator를 그래디언트가 아닌 단색을 쓰겠다는 뜻이다.
    self.indicatorShadowHidden = YES;
    self.isIndicatorBarStyle = configuration.isIndicatorBarStyle;
    [self.fullContainerView addSubview:self.segmentIndicator];
    
    _segmentsStackView = [UIStackView new];
    self.segmentsStackView.axis = UILayoutConstraintAxisHorizontal; // 언제나 항상 이 값이다.
    self.segmentsStackView.spacing = self.interItemSpacing;
    self.segmentsStackView.distribution = UIStackViewDistributionFillEqually; // 세그먼트를 동일하게 분배한다.
    self.segmentsStackView.alignment = UIStackViewAlignmentFill; // 위 아래로 꽉 채운다.
    [self.fullContainerView addSubview:self.segmentsStackView];
    [self.segmentsStackView mgrPinEdgesToSuperviewEdges];
}


#pragma mark - 세터 & 게터
- (void)setConfiguration:(MGXSegmentConfiguration *)configuration {
    if (configuration != nil) {
        _configuration = configuration;
        [self applyConfiguration:configuration];
    } else {
        _configuration = [MGXSegmentConfiguration defaultConfiguration];
        [self applyConfiguration:_configuration];
    }
}

- (NSUInteger)numberOfSegments {
    return self.segments.count;
}

- (void)setBorderColor:(UIColor *)borderColor {
    self.layer.borderColor = [borderColor CGColor];
}

- (UIColor *)borderColor {
    return [UIColor colorWithCGColor:self.layer.borderColor];
}

- (void)setBorderWidth:(CGFloat)borderWidth {
    self.layer.borderWidth = borderWidth;
}

- (CGFloat)borderWidth {
    return self.layer.borderWidth;
}

- (void)setCornerRadiusPercent:(CGFloat)cornerRadiusPercent {
    _cornerRadiusPercent = cornerRadiusPercent;
    [self setNeedsLayout];
}

- (void)setIndicatorCornerRadiusAlwaysZero:(BOOL)indicatorCornerRadiusAlwaysZero {
    _indicatorCornerRadiusAlwaysZero = indicatorCornerRadiusAlwaysZero;
    [self setNeedsLayout];
}

- (void)setSeparatorColor:(UIColor *)separatorColor {
    _separatorColor = separatorColor;
    for (UIView *separatorView in self.separatorViews) {
        separatorView.backgroundColor = separatorColor;
    }
}

- (void)setSeparatorHeightRatio:(CGFloat)separatorHeightRatio {
    _separatorHeightRatio = separatorHeightRatio;
    [self setNeedsLayout];
}

- (void)setDrawsIndicatorGradientBackground:(BOOL)drawsSegmentIndicatorGradientBackground {
    self.segmentIndicator.drawsGradientBackground = drawsSegmentIndicatorGradientBackground;
}

- (BOOL)drawsIndicatorGradientBackground {
    return self.segmentIndicator.drawsGradientBackground;
}

- (void)setIndicatorShadowHidden:(BOOL)segmentIndicatorShadowHidden {
    self.segmentIndicator.segmentIndicatorShadowHidden = segmentIndicatorShadowHidden;
}

- (BOOL)indicatorShadowHidden {
    return self.segmentIndicator.segmentIndicatorShadowHidden;
}

- (void)setIsIndicatorBarStyle:(BOOL)isSegmentIndicatorBarStyle {
    self.segmentIndicator.isSegmentIndicatorBarStyle = isSegmentIndicatorBarStyle;
}

- (BOOL)isIndicatorBarStyle {
    return self.segmentIndicator.isSegmentIndicatorBarStyle;
}

- (void)setIndicatorBackgroundColor:(UIColor *)segmentIndicatorBackgroundColor {
    self.segmentIndicator.backgroundColor = segmentIndicatorBackgroundColor;
}

- (UIColor *)indicatorBackgroundColor {
    return self.segmentIndicator.backgroundColor;
}

- (void)setIndicatorInset:(CGFloat)segmentIndicatorInset {
    _indicatorInset = segmentIndicatorInset;
    [self setNeedsLayout];
}

- (void)setIndicatorGradientTopColor:(UIColor *)segmentIndicatorGradientTopColor {
    self.segmentIndicator.gradientTopColor = segmentIndicatorGradientTopColor;
}

- (UIColor *)indicatorGradientTopColor {
    return self.segmentIndicator.gradientTopColor;
}

- (void)setIndicatorGradientBottomColor:(UIColor *)segmentIndicatorGradientBottomColor {
    self.segmentIndicator.gradientBottomColor = segmentIndicatorGradientBottomColor;
}

- (UIColor *)indicatorGradientBottomColor {
    return self.segmentIndicator.gradientBottomColor;
}

- (void)setIndicatorBorderColor:(UIColor *)segmentIndicatorBorderColor {
    self.segmentIndicator.borderColor = segmentIndicatorBorderColor;
}

- (UIColor *)indicatorBorderColor {
    return self.segmentIndicator.borderColor;
}

- (void)setIndicatorBorderWidth:(CGFloat)segmentIndicatorBorderWidth {
    self.segmentIndicator.borderWidth = segmentIndicatorBorderWidth;
}

- (CGFloat)indicatorBorderWidth {
    return self.segmentIndicator.borderWidth;
}

- (void)setTitleFont:(UIFont *)titleFont {
    _titleFont = titleFont;
    [self setNeedsLayout];
}

- (void)setTitleColor:(UIColor *)titleTextColor {
    _titleColor = titleTextColor;
    [self setNeedsLayout];
}

- (void)setSelectedTitleFont:(UIFont *)selectedTitleFont {
    _selectedTitleFont = selectedTitleFont;
    [self setNeedsLayout];
}

- (void)setSelectedTitleColor:(UIColor *)selectedTitleTextColor {
    _selectedTitleColor = selectedTitleTextColor;
    [self setNeedsLayout];
}

- (void)setImageTintColor:(UIColor *)imageTintColor {
    _imageTintColor = imageTintColor;
    [self setNeedsLayout];
}

- (void)setSelectedImageTintColor:(UIColor *)selectedImageTintColor {
    _selectedImageTintColor = selectedImageTintColor;
    [self setNeedsLayout];
}

- (void)setIsSelectedTextGlowON:(BOOL)isSelectedTextGlowON {
    _isSelectedTextGlowON = isSelectedTextGlowON;
    for(MGXSegment * segment in self.segments) {
        segment.isSelectedTextGlowON = isSelectedTextGlowON;
    }
}

//! 실제로 이 메서드는 외부, 프로그래머에 의해서만 호출된다. 강제로 옮기는 경우에만 호출. 이 클래스 내부에서는 호출되지 않는다.
- (void)setSelectedSegmentIndex:(NSUInteger)selectedSegmentIndex {
    [self setSelectedSegmentIndex:selectedSegmentIndex animated:NO];
}

- (void)setInterItemSpacing:(CGFloat)interItemSpacing {
    _interItemSpacing = interItemSpacing;
    self.segmentsStackView.spacing = interItemSpacing;
}

- (void)setSegmentContentsAxis:(UILayoutConstraintAxis)segmentContentsAxis {
    _segmentContentsAxis = segmentContentsAxis;
    for (MGXSegment *segment in self.segments) {
        segment.stackViewAxis = segmentContentsAxis;
    }
}

- (void)setSegmentContentsSpacing:(UILayoutConstraintAxis)segmentContentsSpacing {
    _segmentContentsSpacing = segmentContentsSpacing;
    for (MGXSegment *segment in self.segments) {
        segment.stackViewSpacing = segmentContentsSpacing;
    }
    
}


#pragma mark - 컨트롤 메서드
- (void)insertSegmentWithModel:(MGXSegmentModel *)segmentModel  // 기존의 control에 세그먼트를 추가적으로 삽입할 때 호
                       atIndex:(NSUInteger)index {
    MGXSegment *newSegment = [MGXSegment segmentWithSegmentModel:segmentModel];
    [self.segmentsStackView insertArrangedSubview:newSegment atIndex:index];
    NSMutableArray *mutableSegments = [NSMutableArray arrayWithArray:self.segments];
    [mutableSegments insertObject:newSegment atIndex:index];
    self.segments = [NSArray arrayWithArray:mutableSegments];
    
    if (self.segments.count > 1) {
        NSMutableArray *mutableSeparatorsArr = [NSMutableArray arrayWithArray:self.separatorViews];
        UIView *separatorView = [UIView new];
        [self.separatorContainerView addSubview:separatorView];
        [mutableSeparatorsArr addObject:separatorView];
        self.separatorViews = [NSArray arrayWithArray:mutableSeparatorsArr];
    }
    
    [self setNeedsLayout];
}

- (void)removeSegmentAtIndex:(NSUInteger)index {
    MGXSegment *segment = self.segments[index];
    [segment removeFromSuperview];
    
    NSMutableArray *mutableSegments = [NSMutableArray arrayWithArray:self.segments];
    [mutableSegments removeObjectAtIndex:index];
    self.segments = [NSArray arrayWithArray:mutableSegments];
    
    if (self.separatorViews.count > 0) {
        UIView *separatorView = self.separatorViews[index];
        [separatorView removeFromSuperview];
        NSMutableArray *mutableSeparatorsArr = [NSMutableArray arrayWithArray:self.separatorViews];
        [mutableSeparatorsArr removeObjectAtIndex:index];
        self.separatorViews = [NSArray arrayWithArray:mutableSeparatorsArr];
    }
    
    [self setNeedsLayout];
}

- (void)removeAllSegments {
    for (MGXSegment *segment in self.segments) {
        [segment removeFromSuperview];
    }
    
    self.segments = [NSArray array];
    
    for (UIView *view in self.separatorViews) {
        [view removeFromSuperview];
    }
    
    self.separatorViews = [NSArray array];
    [self setNeedsLayout];
}

- (void)setModel:(MGXSegmentModel *)segmentModel AtIndex:(NSUInteger)index {
    [self removeSegmentAtIndex:index];
    [self insertSegmentWithModel:segmentModel atIndex:index];
}

- (NSString *)titleForSegmentAtIndex:(NSUInteger)index {
    MGXSegment *segment = self.segments[index];
    return segment.titleLabel.text;
}

- (NSString *)titleForSelectedSegmentIndex {
    return [self titleForSegmentAtIndex:self.selectedSegmentIndex];
}

- (UIImage *)segmentImageForSegmentAtIndex:(NSUInteger)index {
    MGXSegment *segment = self.segments[index];
    return segment.imageView.image;
}

- (UIImage *)segmentImageForSelectedSegmentIndex {
    return [self segmentImageForSegmentAtIndex:self.selectedSegmentIndex];
}

//! 내부에서의 작동을 위해 존재한다. 그러나 손가락 터치 없이 애니메이션을 주면서 움직일 수 있는 경우가 존재할 수 있으므로 public이다.
- (void)setSelectedSegmentIndex:(NSUInteger)selectedSegmentIndex animated:(BOOL)animated {
    [self moveSelectedSegmentIndicatorToSegmentAtIndex:selectedSegmentIndex animated:animated];
    //
    // animated = NO로 설정하면 data source에 알림 없이 이동가능하다.
}

//! 위 메서드를 string으로 작동하게 만들었다.
- (void)setSelectedSegmentTitle:(NSString *)selectedSegmentTitle animated:(BOOL)animated {
    for (int i = 0; i < self.segments.count; i++) {
        if ([selectedSegmentTitle isEqualToString:[self titleForSegmentAtIndex:i]]) {
            [self setSelectedSegmentIndex:i animated:animated];
            return;
        }
    }
    NSAssert(false, @"존재하지 않는 string을 고르려 했다.");
}

- (void)moveSelectedSegmentIndicatorToSegmentAtIndex:(NSUInteger)index animated:(BOOL)animated {
    [self justMoveIndicatorToSegmentAtIndex:index animated:animated];
    if(_selectedSegmentIndex != index) {
        self.segments[_selectedSegmentIndex].selected = NO;
        self.segments[index].selected = YES;
        _selectedSegmentIndex = index;
        if (animated == YES) { //! 애니메이션 없이 설정했다는 것은 프로그래머가 UIControlEventValueChanged 알림 없이 몰래 옮기겠다는 의도이다.
            [self sendActionsForControlEvents:UIControlEventValueChanged];
        }
    }
}

- (void)justMoveIndicatorToSegmentAtIndex:(NSUInteger)index animated:(BOOL)animated {

    [self.segments enumerateObjectsUsingBlock:^(MGXSegment *segment, NSUInteger idx, BOOL *stop) {
        if (index == idx) {
            segment.segmentState = MGXSegmentStateIndicator;
        } else {
            segment.segmentState = MGXSegmentStateNoIndicator;
        }
    }];

    [self hideAndShowSeparatorsAtIndex:index];
    [self.segmentIndicator moveToFrame:[self indicatorFrameAtIndex:index] animated:animated];
}


#pragma mark - 지원 메서드
//! 인수로 던져지는 segment는 선택된 혹은 선택될 segment이다.
- (CGRect)indicatorFrameAtIndex:(NSInteger)index {
    NSInteger count = self.segments.count;
    CGFloat spacing = self.interItemSpacing;
    CGFloat baseWidth = (self.bounds.size.width + spacing * (1 - count )) / count;
    CGRect baseRect = CGRectMake(0.0, 0.0, baseWidth, self.bounds.size.height);
    baseRect.origin.x = (baseWidth + spacing) * index;
    
    CGRect indicatorFrameRect = CGRectMake(CGRectGetMinX(baseRect)   + self.indicatorInset,
                                           CGRectGetMinY(baseRect)   + self.indicatorInset,
                                           CGRectGetWidth(baseRect)  - (2.0f * self.indicatorInset),
                                           CGRectGetHeight(baseRect) - (2.0f * self.indicatorInset));
    return indicatorFrameRect;

    
}

- (CGRect)indicatorMinimumScaleFrameAtIndex:(NSInteger)index {
    
    NSInteger lastIndex = self.segments.count - 1;
    
    CGRect originalIndicatorFrame = [self indicatorFrameAtIndex:index];
    CGRect minimumIndicatorFrame = MGRRectPercent(originalIndicatorFrame, MGXSegmentedControlMinimumScale, MGXSegmentedControlMinimumScale);
    
    if (index != 0 && index != lastIndex) {
        return minimumIndicatorFrame;
    }
    
    CGPoint center = MGRRectGetCenter(minimumIndicatorFrame);
    CGFloat bottom = originalIndicatorFrame.size.height * MGXSegmentedControlHalfShinkRatio; // 아래에서 줄어든 길이
    CGFloat side = originalIndicatorFrame.size.width * MGXSegmentedControlHalfShinkRatio; // 옆에서 줄어든 길이
    CGFloat shiftValue = ABS(side - bottom);

    if (index == 0) {
        return MGRRectAroundCenter(CGPointMake(center.x - shiftValue, center.y), minimumIndicatorFrame.size);
        
    } else { // last index
        return MGRRectAroundCenter(CGPointMake(center.x + shiftValue, center.y), minimumIndicatorFrame.size);
    }

}

// configuration을 적용한다.
- (void)applyConfiguration:(MGXSegmentConfiguration *)configuration {
    self.isSelectedTextGlowON = configuration.isSelectedTextGlowON;
    
    self.titleFont = configuration.titleFont;
    self.selectedTitleFont = configuration.selectedTitleFont;
    
    self.titleColor = configuration.titleColor;
    self.selectedTitleColor = configuration.selectedTitleColor;
    
    self.selectedImageTintColor = configuration.selectedImageTintColor;
    self.imageTintColor = configuration.imageTintColor;
    
    self.borderWidth = configuration.borderWidth;
    self.borderColor = configuration.borderColor;
    self.separatorColor = configuration.separatorColor;
    self.separatorHeightRatio = configuration.separatorHeightRatio;
    
    self.indicatorBorderWidth = configuration.indicatorBorderWidth;
    self.indicatorBorderColor = configuration.indicatorBorderColor;
    
    self.indicatorCornerRadiusAlwaysZero = configuration.indicatorCornerRadiusAlwaysZero;
    self.cornerRadiusPercent = configuration.cornerRadiusPercent;

    /// selected segment indicator가 전체 the control의 outer edge에서 inset되는 양을 의미한다.
    self.indicatorInset = configuration.segmentIndicatorInset;
    
    self.backgroundColor        = configuration.backgroundColor;
    self.drawsGradientBackground = configuration.drawsGradientBackground;
    self.gradientTopColor = configuration.gradientTopColor;
    self.gradientBottomColor = configuration.gradientBottomColor;
    
    self.indicatorBackgroundColor = configuration.indicatorBackgroundColor;
    self.drawsIndicatorGradientBackground = configuration.drawsIndicatorGradientBackground;
    self.indicatorShadowHidden = configuration.indicatorShadowHidden;
    self.isIndicatorBarStyle = configuration.isIndicatorBarStyle;
    self.indicatorGradientTopColor = configuration.indicatorGradientTopColor;
    self.indicatorGradientBottomColor = configuration.indicatorGradientBottomColor;
    
    self.interItemSpacing  = configuration.interItemSpacing;
    self.segmentContentsAxis = configuration.segmentContentsAxis;
    self.segmentContentsSpacing = configuration.segmentContentsSpacing;
}

#pragma mark - 터치에서 사용되는 지원 메서드
//! 현재 터치 포인트에서 가장 가까운 segment의 index를 찾아준다.
- (NSInteger)indexOfSegmentCloseToTouchPoint:(CGPoint)touchPoint {
    NSArray <MGXSegment *>*segments = self.segments;
    segments = [segments sortedArrayUsingComparator:^NSComparisonResult(MGXSegment *segment1, MGXSegment *segment2) {
        CGSize size = segment1.bounds.size;
        CGPoint point1 = [segment1 convertPoint:CGPointMake(size.width/2.0, size.height/2.0) toView:self];
        size = segment2.bounds.size;
        CGPoint point2 = [segment2 convertPoint:CGPointMake(size.width/2.0, size.height/2.0) toView:self];
        if (ABS(point1.x - touchPoint.x) < ABS(point2.x - touchPoint.x)) {
            return NSOrderedAscending;
        } else {
            return NSOrderedDescending;
        }
    }];
    
    return [self.segments indexOfObject:segments.firstObject];
}

- (void)touchUpState:(NSInteger)index {
    CGRect frame = [self indicatorFrameAtIndex:index];
    [self.segmentIndicator shrink:NO frame:frame];
    for (MGXSegment *segment in self.segments) {
        segment.shrink = NO;
        segment.highlight = NO;
    }
}

- (void)hideAndShowSeparatorsAtIndex:(NSInteger)index { // index가 NSNotFound이면 모두 보여준다.
    NSInteger count = self.separatorViews.count;
    for (NSInteger i = 0; i < count; i++) {
        UIView *separatorView = self.separatorViews[i];
        if (i == index - 1 || i == index) {
            separatorView.alpha = 0.0;
        } else {
            CATransition *transition = [CATransition animation];
            [transition setType:kCATransitionFade];
            [transition setDuration:0.3f];
            [separatorView.layer addAnimation:transition forKey:nil];
            separatorView.alpha = 1.0;
        }
    }
}


#pragma mark - UNAVAILABLE
- (instancetype)initWithFrame:(CGRect)frame {
    NSAssert(FALSE, @"- initWithFrame: 사용금지.");
    return nil;
}

- (instancetype)initWithCoder:(NSCoder *)coder {
    NSAssert(FALSE, @"- initWithCoder: 사용금지.");
    return nil;
}

@end
