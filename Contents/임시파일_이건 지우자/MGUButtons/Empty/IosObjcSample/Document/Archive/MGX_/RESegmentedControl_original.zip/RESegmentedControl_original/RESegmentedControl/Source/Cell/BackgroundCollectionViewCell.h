//
//  BackgroundCollectionViewCell.h
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/13.
//

#import <UIKit/UIKit.h>
@class RESegmentedControlPreset;

NS_ASSUME_NONNULL_BEGIN

@interface BackgroundCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UIView *bgView;
@property (weak, nonatomic) IBOutlet UIView *separatorView;
@property (weak, nonatomic, nullable) IBOutlet NSLayoutConstraint *separatorViewWidthLC;
@property (weak, nonatomic, nullable) IBOutlet NSLayoutConstraint *separatorViewLeadingLC;
@property (weak, nonatomic, nullable) IBOutlet NSLayoutConstraint *separatorViewTopLC;
@property (weak, nonatomic, nullable) IBOutlet NSLayoutConstraint *separatorViewBottomLC;

- (void)configureStyle:(RESegmentedControlPreset *)style
    isSeparatorVisible:(BOOL)isSeparatorVisible;

@end

NS_ASSUME_NONNULL_END
