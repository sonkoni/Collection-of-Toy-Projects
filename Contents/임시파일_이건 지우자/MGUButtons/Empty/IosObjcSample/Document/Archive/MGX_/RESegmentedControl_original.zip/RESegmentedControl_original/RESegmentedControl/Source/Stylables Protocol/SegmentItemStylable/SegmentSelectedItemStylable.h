//
//  SegmentSelectedItemStylable.h
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/13.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@protocol ShadowStylable;
@protocol SeparatorStylable;

NS_ASSUME_NONNULL_BEGIN

//! maxHeight 또는 fixedHeight:값 과 position
typedef struct CG_BOXABLE SelectedSegmentSize {
    BOOL isMaxHeight;         // maxHeight
    CGFloat fixedHeight;      // fixedHeight: CGFloat값
    BOOL isFixedHeightPositionTop; // fixedHeight: position : top or bottom
} SelectedSegmentSize;

static SelectedSegmentSize const SelectedSegmentSizeMaxHeight = {YES, 0.0, YES};

CG_INLINE SelectedSegmentSize SelectedSegmentSizeFixedHeightMake(CGFloat height, BOOL isTop) {
    SelectedSegmentSize selectedSegmentSize = {NO, height, isTop};
    return selectedSegmentSize;
}

CG_INLINE BOOL SelectedSegmentSizeIsMaxHeight (SelectedSegmentSize size) {
    if (size.isMaxHeight == YES) {
        return YES;
    } else {
        return NO;
    }
}

@protocol SegmentSelectedItemStylable <NSObject>
@optional
@required

- (UIColor *)backgroundColor;
- (void)setBackgroundColor:(UIColor *)backgroundColor;

- (CGFloat)cornerRadius;
- (void)setCornerRadius:(CGFloat)cornerRadius;

- (CGFloat)borderWidth;
- (void)setBorderWidth:(CGFloat)borderWidth;

- (CGColorRef __nullable)borderColor;
- (void)setBorderColor:(CGColorRef __nullable)borderColor;

- (id <ShadowStylable> _Nullable)shadow;
- (void)setShadow:(id <ShadowStylable> _Nullable)shadow;

- (SelectedSegmentSize)size;
- (void)setSize:(SelectedSegmentSize)size;

- (CGFloat)offset;
- (void)setOffset:(CGFloat)offset;

@end

NS_ASSUME_NONNULL_END
