//
//  RESegmentedControlPreset.h
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/13.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

//! maxHeight 또는 fixedHeight:값
typedef struct CG_BOXABLE SegmentedControlSize {
    BOOL isMaxHeight;       // maxHeight
    CGFloat fixedHeight;    // fixedHeight:값
} SegmentedControlSize;

static SegmentedControlSize const SegmentedControlSizeMaxHeight = {YES, 0.0};

CG_INLINE SegmentedControlSize SegmentedControlSizeFixedHeightMake(CGFloat height) {
    SegmentedControlSize controlSize = {NO, height};
    return controlSize;
}

CG_INLINE BOOL SegmentedControlSizeIsMaxHeight(SegmentedControlSize size) {
    if (size.isMaxHeight == YES) {
        return YES;
    } else {
        return NO;
    }
}


//! maxHeight 또는 fixedHeight:값 과 position
typedef struct CG_BOXABLE SelectedSegmentSize {
    BOOL isMaxHeight;         // maxHeight
    CGFloat fixedHeight;      // fixedHeight: CGFloat값
    BOOL isFixedHeightPositionTop; // fixedHeight: position : top or bottom
} SelectedSegmentSize;

static SelectedSegmentSize const SelectedSegmentSizeMaxHeight = {YES, 0.0, YES};

CG_INLINE SelectedSegmentSize SelectedSegmentSizeFixedHeightMake(CGFloat height, BOOL isTop) {
    SelectedSegmentSize selectedSegmentSize = {NO, height, isTop};
    return selectedSegmentSize;
}

CG_INLINE BOOL SelectedSegmentSizeIsMaxHeight(SelectedSegmentSize size) {
    if (size.isMaxHeight == YES) {
        return YES;
    } else {
        return NO;
    }
}


@interface RESegmentedControlPreset : NSObject


// -MARK: SegmentStylable
@property (nonatomic, assign) CGFloat segmentSpacing; // A space between segments
@property (nonatomic, assign) SegmentedControlSize segmentSize; // Segmented control size type
@property (nonatomic, assign) BOOL segmentClipsToBounds; // segmentedControl을 clipsToBounds 하는지 여부
@property (nonatomic, assign) CGFloat segmentBorderWidth; // Segmented control boder width
@property (nonatomic) CGColorRef segmentBorderColor; // Segmented control border color
@property (nonatomic, assign) CGFloat segmentCornerRadius; // Segmetned control corner radius


// -MARK: SegmentItemStylable
@property (nonatomic, strong) UIColor *backgroundColor; // A segment item background color
@property (nonatomic, strong) UIFont *textFont; // A segment item font
@property (nonatomic, strong, nullable) UIFont *selectedTextFont; // A segment item selected font (Optional)
@property (nonatomic, strong) UIColor *textColor; // A segment item text color
@property (nonatomic, strong) UIColor *tintColor; // A segment item tint color (applied to the image)
@property (nonatomic, strong) UIColor *selectedTextColor; // A segment item selected text color
@property (nonatomic, strong) UIColor *selectedTintColor; // A segment item selected tint color
@property (nonatomic) CGColorRef segmentItemBorderColor; // A segment item border color
@property (nonatomic, assign) CGFloat segmentItemBorderWidth; // A segment item boroder width
@property (nonatomic, assign) CGFloat imageHeight; // A segment item image height
@property (nonatomic, assign) UIImageRenderingMode imageRenderMode; // A segment item image render mode
@property (nonatomic, assign) CGFloat spaceBetweenImageAndLabel; // The space between text and image
@property (nonatomic, assign) CGFloat segmentItemCornerRadius; // A segment item corner radius
@property (nonatomic, assign) UILayoutConstraintAxis segmentItemAxis; // The axis between text and image
// SeparatorStylable
@property (nonatomic, assign) BOOL segmentItemSeparatorHidden;
@property (nonatomic, strong) UIColor *segmentItemSeparatorColor;
@property (nonatomic, assign) CGFloat segmentItemSeparatorWidth;
@property (nonatomic, assign) CGFloat segmentItemSeparatorOffset;
// ShadowStylable
@property (nonatomic, assign) BOOL segmentItemShadowHidden;
@property (nonatomic) CGColorRef segmentItemShadowColor;
@property (nonatomic, assign) CGFloat segmentItemShadowOpacity;
@property (nonatomic, assign) CGSize segmentItemShadowOffset;
@property (nonatomic, assign) CGFloat segmentItemShadowRadius;
@property (nonatomic, nullable) CGPathRef segmentItemShadowPath;


// -MARK: SegmentSelectedItemStylable
@property (nonatomic, strong) UIColor *selectedSegmentItemColor; // Selected segment item background color
@property (nonatomic) CGColorRef selectedSegmentItemBoderColor; // Selected segment item border color
@property (nonatomic, assign) CGFloat selectedSegmentItemBorderWidth; // Selected segment item border width
@property (nonatomic, assign) CGFloat selectedSegmentItemCornerRadius; // Selected segment item corner radius
@property (nonatomic, assign) SelectedSegmentSize selectedSegmentItemSizeType; // Selected segment item size type
@property (nonatomic, assign) CGFloat selectedSegmentItemOffset; // Selected segment item offset

// shadow
@property (nonatomic, assign) BOOL selectedSegmentItemShadowHidden;
@property (nonatomic) CGColorRef selectedSegmentItemShadowColor;
@property (nonatomic, assign) CGFloat selectedSegmentItemShadowOpacity;
@property (nonatomic, assign) CGSize selectedSegmentItemShadowOffset;
@property (nonatomic, assign) CGFloat selectedSegmentItemShadowRadius;
@property (nonatomic, nullable) CGPathRef selectedSegmentItemShadowPath;


//!------------------------------------------------------------------------------------
+ (RESegmentedControlPreset *)defaultConfiguration;
+ (RESegmentedControlPreset *)iOS13PresetConfiguration;
+ (RESegmentedControlPreset *)iOS7PresetConfigurationWithTintColor:(UIColor *)tintColor;
+ (RESegmentedControlPreset *)materialConfigurationWithBackgroundColor:(UIColor *)backgroundColor
                                                             tintColor:(UIColor *)tintColor;

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
