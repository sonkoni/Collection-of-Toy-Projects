//
//  SegmentModel.m
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/13.
//

#import "SegmentModel.h"

@implementation SegmentModel
@dynamic isImageAvailable;

#pragma mark - 생성 & 소멸
- (instancetype)initWithTitle:(NSString * _Nullable)title {
    self = [super init];
    if (self) {
        _title = title;
    }
    return self;
}

- (instancetype)initWithTitle:(NSString * _Nullable)title
                    imageName:(NSString * _Nullable)imageName
                       bundle:(NSBundle * _Nullable)bundle {\
    self = [self initWithTitle:title];
    if (self) {
        _imageName = imageName;
        _bundle = bundle;
    }
    
    return self;
}

- (instancetype)initWithTitle:(NSString * _Nullable)title
                     imageUrl:(NSString * _Nullable)imageUrl {
    self = [self initWithTitle:title];
    if (self) {
        if (imageUrl) {
            _imageUrl = [[NSURL alloc] initWithString:imageUrl];
        }
    }
    
    return self;
}


#pragma mark - read only getter
- (BOOL)isImageAvailable {
    if (self.imageUrl != nil) {
        return YES;
    }
    
    if (self.imageName != nil && ([self.imageName isEqualToString:@""] == NO)) {
        return YES;
    }
    
    return NO;
}

@end
