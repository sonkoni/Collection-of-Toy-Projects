//
//  SegmentItemStylable.h
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/13.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@protocol ShadowStylable;
@protocol SeparatorStylable;

NS_ASSUME_NONNULL_BEGIN

@protocol SegmentItemStylable <NSObject>
@optional
@required

- (UIColor *)textColor;
- (void)setTextColor:(UIColor *)textColor;

- (UIColor *)tintColor;
- (void)setTintColor:(UIColor *)tintColor;

- (UIColor *)selectedTextColor;
- (void)setSelectedTextColor:(UIColor *)selectedTextColor;

- (UIColor *)selectedTintColor;
- (void)setSelectedTintColor:(UIColor *)selectedTintColor;

- (UIColor *)backgroundColor;
- (void)setBackgroundColor:(UIColor *)backgroundColor;

- (CGFloat)borderWidth;
- (void)setBorderWidth:(CGFloat)borderWidth;

- (CGColorRef __nullable)borderColor;
- (void)setBorderColor:(CGColorRef __nullable)borderColor;

- (UIFont *)font;
- (void)setFont:(UIFont *)font;

- (UIFont * _Nullable)selectedFont;
- (void)setSelectedFont:(UIFont * _Nullable)selectedFont;

- (CGFloat)imageHeight;
- (void)setImageHeight:(CGFloat)imageHeight;

- (UIImageRenderingMode)imageRenderMode;
- (void)setImageRenderMode:(UIImageRenderingMode)imageRenderMode;

- (CGFloat)spacing;
- (void)setSpacing:(CGFloat)spacing;

- (CGFloat)cornerRadius;
- (void)setCornerRadius:(CGFloat)cornerRadius;

- (id <ShadowStylable> _Nullable)shadow;
- (void)setShadow:(id <ShadowStylable> _Nullable)shadow;

- (id <SeparatorStylable> _Nullable)separator;
- (void)setSeparator:(id <SeparatorStylable> _Nullable)separator;

- (UILayoutConstraintAxis)axis;
- (void)setAxis:(UILayoutConstraintAxis)axis;

@end

NS_ASSUME_NONNULL_END
