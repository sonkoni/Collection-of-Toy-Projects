//
//  RESegmentedControlPreset.m
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/13.
//

#import "RESegmentedControlPreset.h"

@implementation RESegmentedControlPreset

- (instancetype)init {
    self  = [super init];
    if (self) {
        [self commonInit];
    }
    return self;
}


#pragma mark - 생성 & 소멸 메서드
+ (RESegmentedControlPreset *)defaultConfiguration {
    return [[RESegmentedControlPreset alloc] init];
}


- (void)commonInit {
    // -MARK: SegmentStylable
    _segmentSpacing = 0.0f;
    _segmentBorderWidth = 0.0f;
    _segmentBorderColor = NULL;
    _segmentClipsToBounds = NO;
    _segmentCornerRadius = 0.0f;
    _segmentSize = SegmentedControlSizeMaxHeight;
    
    
    // -MARK: SegmentItemStylable
    _backgroundColor = [UIColor whiteColor];
    _textFont = [UIFont systemFontOfSize:11.0 weight:UIFontWeightSemibold];
    _selectedTextFont = [UIFont systemFontOfSize:11.0 weight:UIFontWeightBold];
    _textColor = [UIColor darkGrayColor];
    _tintColor = [UIColor darkGrayColor];
    _selectedTextColor = [UIColor blackColor];
    _selectedTintColor = [UIColor blackColor];
    _segmentItemBorderColor = NULL;
    _segmentItemBorderWidth = 0.0f;
    _imageHeight = 15.0f;
    _imageRenderMode = UIImageRenderingModeAutomatic;
    _spaceBetweenImageAndLabel = 5.0f;
    _segmentItemCornerRadius = 0.0f;
    _segmentItemAxis = UILayoutConstraintAxisHorizontal;
    
    // SeparatorStylable
    _segmentItemSeparatorHidden = YES;
//    @property (nonatomic, strong) UIColor *segmentItemSeparatorColor;
//    @property (nonatomic, assign) CGFloat segmentItemSeparatorWidth;
//    @property (nonatomic, assign) CGFloat segmentItemSeparatorOffset;
    
    // ShadowStylable
    _segmentItemShadowHidden = YES;
//    @property (nonatomic) CGColorRef segmentItemShadowColor;
//    @property (nonatomic, assign) CGFloat segmentItemShadowOpacity;
//    @property (nonatomic, assign) CGSize segmentItemShadowOffset;
//    @property (nonatomic, assign) CGFloat segmentItemShadowRadius;
//    @property (nonatomic) CGPathRef segmentItemShadowPath;
    
    
    // -MARK: SegmentSelectedItemStylable
    _selectedSegmentItemColor = [UIColor yellowColor];
    _selectedSegmentItemBoderColor = NULL;
    _selectedSegmentItemBorderWidth = 0.0f;
    _selectedSegmentItemCornerRadius = 0.0f;
    _selectedSegmentItemSizeType = SelectedSegmentSizeMaxHeight;
    _selectedSegmentItemOffset = 0.0f;

    // shadow
    _selectedSegmentItemShadowHidden = YES;
//    @property (nonatomic) CGColorRef selectedSegmentItemShadowColor;
//    @property (nonatomic, assign) CGFloat selectedSegmentItemShadowOpacity;
//    @property (nonatomic, assign) CGSize selectedSegmentItemShadowOffset;
//    @property (nonatomic, assign) CGFloat selectedSegmentItemShadowRadius;
//    @property (nonatomic) CGPathRef selectedSegmentItemShadowPath;
}

+ (RESegmentedControlPreset *)iOS13PresetConfiguration {
    RESegmentedControlPreset *configuration = [[RESegmentedControlPreset alloc] init];

    // -MARK: SegmentStylable
    configuration.segmentSize = SegmentedControlSizeFixedHeightMake(29.0);
    configuration.segmentClipsToBounds = YES;
    configuration.segmentCornerRadius = 6.0f;
    
    // -MARK: SegmentItemStylable
    configuration.textColor = [UIColor blackColor];
    configuration.tintColor = [UIColor blackColor];
    configuration.backgroundColor =
    [UIColor colorWithRed:0.9333333333 green:0.9333333333 blue:0.9411764706 alpha:1.0];
    configuration.textFont = [UIFont systemFontOfSize:13.0];
    configuration.selectedTextFont = [UIFont systemFontOfSize:13.0 weight:UIFontWeightSemibold];
    configuration.imageRenderMode = UIImageRenderingModeAlwaysTemplate;

    // SeparatorStylable
    configuration.segmentItemSeparatorHidden = NO;
    configuration.segmentItemSeparatorColor =
    [UIColor colorWithRed:0.8745098039 green:0.8745098039 blue:0.8784313725 alpha:1.0];
    configuration.segmentItemSeparatorWidth = 1.0f;
    configuration.segmentItemSeparatorOffset = 5.0f;
    
    // -MARK: SegmentSelectedItemStylable
    configuration.selectedSegmentItemColor = [UIColor whiteColor];
    configuration.selectedSegmentItemCornerRadius = 6.0f;
    configuration.selectedSegmentItemOffset = 2.0f;

    // shadow
    configuration.selectedSegmentItemShadowHidden = NO;
    configuration.selectedSegmentItemShadowColor = [UIColor blackColor].CGColor;
    configuration.selectedSegmentItemShadowOpacity = 0.2f;
    configuration.selectedSegmentItemShadowOffset = CGSizeZero;
    configuration.selectedSegmentItemShadowRadius = 5.0f;
    configuration.selectedSegmentItemShadowPath = NULL;
    return configuration;
}

+ (RESegmentedControlPreset *)iOS7PresetConfigurationWithTintColor:(UIColor *)tintColor {
    RESegmentedControlPreset *configuration = [[RESegmentedControlPreset alloc] init];
    
    if (tintColor == nil) {
        tintColor = [UIColor blueColor];
    }

    // -MARK: SegmentStylable
    configuration.segmentSize = SegmentedControlSizeFixedHeightMake(29.0);
    configuration.segmentClipsToBounds = YES;
    configuration.segmentBorderWidth = 1.0f;
    configuration.segmentBorderColor = tintColor.CGColor;
    configuration.segmentCornerRadius = 5.0f;
    
    
    // -MARK: SegmentItemStylable
    configuration.textColor = tintColor;
    configuration.tintColor = tintColor;
    configuration.selectedTextColor = [UIColor whiteColor];
    configuration.selectedTintColor = [UIColor whiteColor];
    configuration.backgroundColor = [UIColor whiteColor];
    configuration.textFont = [UIFont systemFontOfSize:13.0];
    configuration.selectedTextFont = nil;
    configuration.imageRenderMode = UIImageRenderingModeAlwaysTemplate;

    // SeparatorStylable
    configuration.segmentItemSeparatorHidden = NO;
    configuration.segmentItemSeparatorColor = tintColor;
    configuration.segmentItemSeparatorWidth = 1.0f;
    configuration.segmentItemSeparatorOffset = 0.0f;
    
    
    // -MARK: SegmentSelectedItemStylable
    configuration.selectedSegmentItemColor = tintColor;
    
    return configuration;
}

+ (RESegmentedControlPreset *)materialConfigurationWithBackgroundColor:(UIColor *)backgroundColor
                                                             tintColor:(UIColor *)tintColor {
    RESegmentedControlPreset *configuration = [[RESegmentedControlPreset alloc] init];
    
    if (backgroundColor == nil) {
        backgroundColor = [UIColor whiteColor];
    }
    
    if (tintColor == nil) {
        tintColor = [UIColor blackColor];
    }

    // -MARK: SegmentStylable
    configuration.segmentClipsToBounds = YES;
    
    
    // -MARK: SegmentItemStylable
    configuration.textColor = [UIColor whiteColor];
    configuration.tintColor = [UIColor whiteColor];
    configuration.selectedTextColor = tintColor;
    configuration.selectedTintColor = tintColor;
    configuration.backgroundColor = backgroundColor;
    configuration.textFont = [UIFont systemFontOfSize:13.0 weight:UIFontWeightSemibold];
    configuration.selectedTextFont = nil;
    configuration.imageRenderMode = UIImageRenderingModeAlwaysTemplate;
    
    
    // -MARK: SegmentSelectedItemStylable
    configuration.selectedSegmentItemColor = tintColor; // 기본이 white
    configuration.selectedSegmentItemSizeType = SelectedSegmentSizeFixedHeightMake(5.0f, NO);
    return configuration;
}
@end
