//
//  MGRSegment.h
//  MGRButtons
//
//  Created by Kwan Hyun Son on 13/08/2019.
//  Copyright © 2019 Mulgrim Inc. All rights reserved.
//
// 인디케이터 스테이트, 쉬링크, 하이라이트.

#import <UIKit/UIKit.h>
@class MGXSegmentModel;

typedef NS_ENUM(NSUInteger, MGXSegmentState) {
    MGXSegmentStateNoIndicator = 1,      // 인디케이터가 위치하지 않은 곳의 segment 상태
    MGXSegmentStateIndicator             // 인디케이터가 있는 곳의 segment 상태
};

@interface MGXSegment : UIView

@property (nonatomic, strong) UIImageView *imageView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic) BOOL selected;
@property (nonatomic) MGXSegmentState segmentState;

@property (nonatomic) CGFloat stackViewSpacing;
@property (nonatomic) UILayoutConstraintAxis stackViewAxis;
@property (nonatomic, strong) NSLayoutConstraint *imageViewHeightLayoutConstraint;

@property (nonatomic, strong) UIFont  *font;
@property (nonatomic, strong) UIColor *titleColor;
@property (nonatomic) UIColor *imageTintColor;

@property (nonatomic, strong) UIFont  *selectedFont;
@property (nonatomic, strong) UIColor *selectedTitleColor;
@property (nonatomic) UIColor *selectedImageTintColor;

@property (nonatomic, assign) BOOL isSelectedTextGlowON;

@property (nonatomic) BOOL shrink; // MGRSegmentedControl의 Pan으로 작동한다.
@property (nonatomic) BOOL highlight; // MGRSegmentedControl의 Pan으로 작동한다.

- (instancetype)initWithSegmentModel:(MGXSegmentModel *)model NS_DESIGNATED_INITIALIZER;
+ (instancetype)segmentWithSegmentModel:(MGXSegmentModel *)model; // convenience.

+ (instancetype)new NS_UNAVAILABLE;
- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithFrame:(CGRect)frame NS_UNAVAILABLE;
- (instancetype)initWithCoder:(NSCoder *)aDecoder NS_UNAVAILABLE;

@end
