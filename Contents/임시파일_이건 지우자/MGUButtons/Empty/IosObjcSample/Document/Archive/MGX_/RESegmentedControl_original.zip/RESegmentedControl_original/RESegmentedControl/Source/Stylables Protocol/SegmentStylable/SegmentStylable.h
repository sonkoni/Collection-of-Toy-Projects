//
//  SegmentStylable.h
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/13.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

//! maxHeight 또는 fixedHeight:값
typedef struct CG_BOXABLE SegmentedControlSize {
    BOOL isMaxHeight;       // maxHeight
    CGFloat fixedHeight;    // fixedHeight:값
} SegmentedControlSize;

static SegmentedControlSize const SegmentedControlSizeMaxHeight = {YES, 0.0};

CG_INLINE SegmentedControlSize SegmentedControlSizeFixedHeightMake(CGFloat height) {
    SegmentedControlSize controlSize = {NO, height};
    return controlSize;
}

CG_INLINE BOOL SegmentedControlSizeIsMaxHeight (SegmentedControlSize size) {
    if (size.isMaxHeight == YES) {
        return YES;
    } else {
        return NO;
    }
}

@protocol SegmentStylable <NSObject>
@optional
@required
- (SegmentedControlSize)size;
- (void)setSize:(SegmentedControlSize)size;

- (CGFloat)spacing;
- (void)setSpacing:(CGFloat)spacing;

- (BOOL)clipsToBounds;
- (void)setClipsToBounds:(BOOL)clipsToBounds;

- (CGFloat)borderWidth;
- (void)setBorderWidth:(CGFloat)borderWidth;

- (CGColorRef __nullable)borderColor;
- (void)setBorderColor:(CGColorRef __nullable)borderColor;

- (CGFloat)cornerRadius;
- (void)setCornerRadius:(CGFloat)cornerRadius;

@end

NS_ASSUME_NONNULL_END
