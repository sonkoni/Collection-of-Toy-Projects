//
//  ImageDownloader.m
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/14.
//

#import "ImageDownloader.h"
#import "NSURL+Filename.h"
#import "NSFileManager+Extention.h"

@interface ImageDownloader ()
@property (nonatomic, strong, nullable) NSURLSessionDataTask *task;
@end

@implementation ImageDownloader
static NSError * _downloadFailed;

+ (NSError *)downloadFailed {
    return _downloadFailed;
}

+ (void)setDownloadFailed:(NSError *)downloadFailed {
    _downloadFailed = downloadFailed;
}


#pragma mark - 인스턴스 메서드.
- (void)downloadImageUrl:(NSURL *)url
              completion:(void(^)(UIImage *image, NSURL *url, NSError *error))completion {
    
    UIImage *cachedImage = [self imageDataFrom:url];
    if (cachedImage != nil) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (completion != nil) {
                completion(cachedImage, url, nil);
            }
        });
    } else {
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_BACKGROUND, 0), ^{
            NSURLSessionConfiguration * configuration =
            [NSURLSessionConfiguration defaultSessionConfiguration];
            
            NSURLSession *session = [NSURLSession sessionWithConfiguration:configuration];
            
            self.task = [session dataTaskWithURL:url
                               completionHandler:^(NSData * _Nullable data,
                                                   NSURLResponse * _Nullable response,
                                                   NSError * _Nullable error) {
                if (error != nil) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        if (completion != nil) {
                            completion(nil, url, error);
                        }
                    });
                    return;
                }
                
                UIImage *image = [[UIImage alloc] initWithData:data];
                if (data == nil || image == nil) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        if (completion != nil) {
                            completion(nil, url, [ImageDownloader downloadFailed]);
                        }
                    });
                    return;
                }
                
                [self save:data fromUrl:url];
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (completion != nil) {
                        completion(image, url, nil);
                    }
                });
            }];
            
            [self.task resume];
        });
    }
}

- (void)cancel {
    [self.task cancel];
}


#pragma mark - private
- (NSURL * _Nullable)save:(NSData *)data fromUrl:(NSURL *)remoteUrl {
    NSString *filename = remoteUrl.filename;
    if (filename == nil) {
        return nil;
    }
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    return [fileManager saveImage:data filename:filename];
}

- (UIImage * _Nullable)imageDataFrom:(NSURL *)remoteUrl {
    NSString *filename = remoteUrl.filename;
    if (filename == nil) {
        return nil;
    }
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSData *data = [fileManager imageDataFilename:filename];
    if (data == nil) {
        return nil;
    }
    
    return [[UIImage alloc] initWithData:data];
}

@end
