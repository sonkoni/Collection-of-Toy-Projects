//
//  ImageDownloader.h
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/14.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

//enum ImageError: Error {
//    case downloadFailed
//}

@interface ImageDownloader : NSObject
@property (class, nonatomic, strong) NSError *downloadFailed;
- (void)downloadImageUrl:(NSURL *)url
              completion:(void(^)(UIImage *image, NSURL *url, NSError *error))completion;
- (void)cancel;
@end

NS_ASSUME_NONNULL_END
