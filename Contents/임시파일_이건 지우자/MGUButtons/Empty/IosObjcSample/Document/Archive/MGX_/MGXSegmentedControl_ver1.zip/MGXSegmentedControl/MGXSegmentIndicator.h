//
//  MGRSegmentIndicator.m
//  MGRButtons
//
//  Created by Kwan Hyun Son on 13/08/2019.
//  Copyright © 2019 Mulgrim Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MGXSegmentIndicator : UIView

@property (nonatomic) CGFloat  cornerRadius;
@property (nonatomic) CGFloat  borderWidth;  // @dynamic
@property (nonatomic) UIColor *borderColor;  // @dynamic

// =============================================================================
//! 사용하지 않고 그냥 단색으로 갈 수 있다.
@property (nonatomic) BOOL     drawsGradientBackground; // @dynamic
@property (nonatomic) BOOL     segmentIndicatorShadowHidden;
@property (nonatomic) BOOL     isSegmentIndicatorBarStyle;
@property (nonatomic) UIColor *gradientTopColor;        // @dynamic
@property (nonatomic) UIColor *gradientBottomColor;     // @dynamic

@property (nonatomic, readonly) BOOL shrink;

- (void)shrink:(BOOL)isShrink frame:(CGRect)frame;  // MGRSegmentedControl의 Pan으로 작동한다.
- (void)moveToFrame:(CGRect)frame animated:(BOOL)animated;
@end
