//
//  SegmentModel.h
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/13.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SegmentModel : NSObject
@property (nonatomic, strong, nullable) NSString *title;
@property (nonatomic, strong, nullable) NSString *imageName;
@property (nonatomic, strong, nullable) NSBundle *bundle;
@property (nonatomic, strong, nullable) NSURL *imageUrl;

@property (nonatomic, assign, readonly) BOOL isImageAvailable; // @dynamic

- (instancetype)initWithTitle:(NSString * _Nullable)title;

- (instancetype)initWithTitle:(NSString * _Nullable)title
                    imageName:(NSString * _Nullable)imageName
                       bundle:(NSBundle * _Nullable)bundle;

- (instancetype)initWithTitle:(NSString * _Nullable)title
                     imageUrl:(NSString * _Nullable)imageUrl;


@end

NS_ASSUME_NONNULL_END
