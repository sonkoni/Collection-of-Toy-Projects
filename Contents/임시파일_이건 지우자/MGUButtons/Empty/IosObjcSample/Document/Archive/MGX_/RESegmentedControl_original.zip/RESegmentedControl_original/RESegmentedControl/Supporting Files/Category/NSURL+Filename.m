//
//  NSURL+Filename.m
//  RESegmentedControl
//
//  Created by Kwan Hyun Son on 2020/11/14.
//

#import "NSURL+Filename.h"
#import "NSData+HexEncodedString.h"

@implementation NSURL (Filename)

/// Hashed filename from remote url path
- (NSString *)filename {
    
    NSData *urlStringData = [self.absoluteString dataUsingEncoding:NSUTF8StringEncoding
                                              allowLossyConversion:NO];
    if (urlStringData == nil) {
        return nil;
    }
    
    return [urlStringData hexEncodedString];
}


@end
