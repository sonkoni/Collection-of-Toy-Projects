//
//  OGSwitch.h
//  OGSwitch
//
//  Created by Oskar Groth on 2018-07-14.
//  Copyright © 2018 Oskar Groth. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for OGSwitch.
FOUNDATION_EXPORT double OGSwitchVersionNumber;

//! Project version string for OGSwitch.
FOUNDATION_EXPORT const unsigned char OGSwitchVersionString[];
