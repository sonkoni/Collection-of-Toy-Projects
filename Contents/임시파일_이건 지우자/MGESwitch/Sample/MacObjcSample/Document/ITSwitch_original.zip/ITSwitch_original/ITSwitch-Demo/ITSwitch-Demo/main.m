//
//  main.m
//  ITSwitch-Demo
//
//  Created by Ilija Tovilo on 01.04.18.
//  Copyright © 2018 Ilija Tovilo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
