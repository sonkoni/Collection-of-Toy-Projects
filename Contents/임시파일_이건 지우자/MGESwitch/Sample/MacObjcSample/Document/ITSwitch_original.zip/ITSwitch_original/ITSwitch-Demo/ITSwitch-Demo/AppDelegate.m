//
//  AppDelegate.m
//  ITSwitch-Demo
//
//  Created by Ilija Tovilo on 01.04.18.
//  Copyright © 2018 Ilija Tovilo. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
}


- (void)applicationWillTerminate:(NSNotification *)aNotification {
    // Insert code here to tear down your application
}


@end
