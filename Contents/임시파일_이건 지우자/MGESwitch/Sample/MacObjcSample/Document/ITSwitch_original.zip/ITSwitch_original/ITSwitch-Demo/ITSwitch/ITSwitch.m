//
//  ITSwitch.m
//  ITSwitch-Demo
//
//  Created by Ilija Tovilo on 01/02/14.
//  Copyright (c) 2014 Ilija Tovilo. All rights reserved.
//

#import "ITSwitch.h"
#import <QuartzCore/QuartzCore.h>
#import "NSHapticFeedbackManager+MGRMacKit.h"


#pragma mark - Static Constants
static CGFloat const kGoldenRatio = 1.61803398875;
static CGFloat const kDecreasedGoldenRatio = 1.38;

static CGFloat const kEnabledOpacity = 1.0;
static CGFloat const kDisabledOpacity = 0.5;


#pragma mark - Interface Extension
@interface ITSwitch () {
//    __weak id _target;
//    SEL _action;
}

@property (nonatomic, getter = isActive) BOOL active;
@property (nonatomic, getter = hasDragged) BOOL dragged;
@property (nonatomic, getter = isDraggingTowardsOn) BOOL draggingTowardsOn;

@property (nonatomic, strong) CALayer *backgroundLayer;
@property (nonatomic, strong) CALayer *knobLayer;
@property (nonatomic, strong) CALayer *knobInsideLayer;

@property (nonatomic, readonly) CGFloat borderLineWidth; // @dynamic
@end



#pragma mark - ITSwitch
@implementation ITSwitch
@dynamic borderLineWidth;
//@synthesize tintColor = _tintColor, disabledBorderColor = _disabledBorderColor;
//- (id)target {
//    return _target;
//}

//- (void)setTarget:(id)target {
//    _target = target;
//}

//- (SEL)action {
//    return _action;
//}
//
//- (void)setAction:(SEL)action {
//    _action = action;
//}


#pragma mark -- OVERRIDE NSResponder
- (BOOL)acceptsFirstResponder {
    return [NSApp isFullKeyboardAccessEnabled];
}

- (void)mouseDown:(NSEvent *)theEvent {
    if (self.isEnabled == YES) {
        self.active = YES;
        [self reloadLayer];
    }
}

- (void)mouseDragged:(NSEvent *)theEvent {
    if (self.isEnabled == YES) {
        self.dragged = YES;
        NSPoint draggingPoint = [self convertPoint:[theEvent locationInWindow] fromView:nil];
        self.draggingTowardsOn = draggingPoint.x >= self.bounds.size.width / 2.0;
        [self reloadLayer];
    }
}

- (void)mouseUp:(NSEvent *)theEvent {
    if (self.isEnabled == YES) {
        self.active = NO;
        BOOL checked = (![self hasDragged]) ? ![self checked] : [self isDraggingTowardsOn];
        BOOL invokeTargetAction = (checked != [self checked]);
        
        self.checked = checked;
        if (invokeTargetAction == YES) {
            [self _invokeTargetAction];
        }
        
        // Reset
        self.dragged = NO;
        self.draggingTowardsOn = NO;
        [self reloadLayer];
    }
}

#pragma mark -- OVERRIDE NSResponder : Key board
- (void)moveLeft:(id)sender { // 좌측 화살표. 퍼스트리스폰더일 때만 작동함.
    if ([self checked] == YES) {
        self.checked = NO;
        [self _invokeTargetAction];
    }
}

- (void)moveRight:(id)sender { // 우측 화살표. 퍼스트리스폰더일 때만 작동함.
    if ([self checked] == NO) {
        self.checked = YES;
        [self _invokeTargetAction];
    }
}

- (BOOL)performKeyEquivalent:(NSEvent *)theEvent {
//     스위치가 퍼스트 리스폰더이면 스페이스로 움직이겠다.
    if (self.window.firstResponder == self) {
        NSInteger ch = [theEvent keyCode];
        if (ch == 49) { // Space
            self.checked = ![self checked];
            [self _invokeTargetAction];
            return YES;
        }
    }
    return NO;
}


#pragma mark -- OVERRIDE NSVIEW
- (instancetype)initWithCoder:(NSCoder *)coder {
    self = [super initWithCoder:coder];
    if (self) {
        CommonInit(self);
    }
    return self;
}

- (instancetype)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        CommonInit(self);
    }
    return self;
}

- (void)setFrameSize:(NSSize)newSize {
    [super setFrameSize:newSize];
    [self reloadLayerSize];
}

- (void)drawFocusRingMask { // 포커스 링의 바운더리를 잡아준다.
    CGFloat cornerRadius = self.bounds.size.height / 2.0;
    NSBezierPath *path = [NSBezierPath bezierPathWithRoundedRect:[self bounds] xRadius:cornerRadius yRadius:cornerRadius];
    [[NSColor blackColor] set];
    [path fill];
}

- (NSRect)focusRingMaskBounds {
    return [self bounds];
}

- (BOOL)acceptsFirstMouse:(NSEvent *)theEvent {
    return YES;
}

- (BOOL)canBecomeKeyView {
    return [NSApp isFullKeyboardAccessEnabled];
}

- (void)setEnabled:(BOOL)enabled {
    [super setEnabled:enabled];
    [self reloadLayer];
}


#pragma mark - 생성 & 소멸
static void CommonInit(ITSwitch *self) {
    self->_animationDuration = 0.4;
    self->_disabledBorderColor = [NSColor colorWithCalibratedWhite:0.0 alpha:0.2];
    self->_tintColor = [NSColor colorWithCalibratedRed:0.27 green:0.86 blue:0.36 alpha:1.0];
    self->_disabledBackgroundColor = [NSColor clearColor];
    
    
    // The Switch is enabled per default
    self.enabled = YES;
    
    // Set up the layer hierarchy
    [self setUpLayers];
    
    //! OGSwitch...
//    reloadLayerSize()
//    setupIcon()
//    reloadLayer()
}

- (void)setUpLayers {
    // Root layer
    self.layer = [CALayer layer]; // self.layer.delegate = self;
    self.wantsLayer = YES;
    self.layer.masksToBounds = NO; // Allow shadow to flow over bounds of the layer

    // Background layer
    _backgroundLayer = [CALayer layer];
    self.backgroundLayer.autoresizingMask = kCALayerWidthSizable | kCALayerHeightSizable;
    self.backgroundLayer.bounds = self.layer.bounds;
    self.backgroundLayer.anchorPoint = CGPointZero;
    self.backgroundLayer.borderWidth = self.borderLineWidth;
    self.backgroundLayer.masksToBounds = NO;
    [self.layer addSublayer:self.backgroundLayer];
    
    // Knob layer
    _knobLayer = [CALayer layer];
    self.knobLayer.frame = [self rectForKnob];
    self.knobLayer.autoresizingMask = kCALayerHeightSizable;
    self.knobLayer.backgroundColor = [NSColor colorWithCalibratedWhite:1.0 alpha:1.0].CGColor;
    self.knobLayer.shadowColor = [[NSColor blackColor] CGColor];
    self.knobLayer.shadowOffset = CGSizeMake(0.0, -2.0); // -6.5
    self.knobLayer.shadowRadius = 1.0; // 2.5
    self.knobLayer.shadowOpacity = 0.3; // 0.15
    [self.layer addSublayer:self.knobLayer];
    
    _knobInsideLayer = [CALayer layer];
    self.knobInsideLayer.frame = self.knobLayer.bounds;
    self.knobInsideLayer.autoresizingMask = kCALayerWidthSizable | kCALayerHeightSizable;
    self.knobInsideLayer.shadowColor = [[NSColor blackColor] CGColor];
    self.knobInsideLayer.shadowOffset = CGSizeZero;
    self.knobInsideLayer.backgroundColor = [[NSColor whiteColor] CGColor];
    self.knobInsideLayer.shadowRadius = 1.0;
    self.knobInsideLayer.shadowOpacity = 0.35;
    [self.knobLayer addSublayer:self.knobInsideLayer];
    
    // Initial
    [self reloadLayerSize];
    [self reloadLayer];
}


#pragma mark - Update Layer
- (void)reloadLayer {
    [CATransaction begin];
    [CATransaction setAnimationDuration:self.animationDuration];
    {
        // ------------------------------- Animate Colors
        if ( ([self hasDragged] == YES && [self isDraggingTowardsOn] == YES) ||
             ([self hasDragged] == NO && [self checked] == YES) ) {
            self.backgroundLayer.borderColor = [self.tintColor CGColor];
            self.backgroundLayer.backgroundColor = [self.tintColor CGColor];
            // 온 쪽에서 스위치가 존재할때. 오른쪽.
        } else {
            // 오프쪽에서 스위치가 존재할때. 왼쪽.
            self.backgroundLayer.borderColor = self.disabledBorderColor.CGColor;
            self.backgroundLayer.backgroundColor = self.disabledBackgroundColor.CGColor;
        }
        
        // ------------------------------- Animate Enabled-Disabled state
        self.layer.opacity = (self.isEnabled) ? kEnabledOpacity : kDisabledOpacity; // 현재 프로젝트 그냥 1.0
        
        // ------------------------------- Animate Frame
        if ([self hasDragged] == NO) {
            CAMediaTimingFunction *function = [CAMediaTimingFunction functionWithControlPoints:0.25 :1.5 :0.5 :1.0];
            [CATransaction setAnimationTimingFunction:function];
        }
        
        self.knobLayer.frame = [self rectForKnob];
        self.knobInsideLayer.frame = self.knobLayer.bounds;
    }
    [CATransaction commit];
}

- (void)reloadLayerSize { // 애니메이션 없이. 프레임 사이즈가 변하면 layoutSubview랑 비슷하게.
    [CATransaction begin];
    [CATransaction setDisableActions:YES];
    {
        self.knobLayer.frame = [self rectForKnob];
        self.knobInsideLayer.frame = self.knobLayer.bounds;
        self.backgroundLayer.cornerRadius = self.backgroundLayer.bounds.size.height / 2.0;
        self.knobLayer.cornerRadius = self.knobLayer.bounds.size.height / 2.0;
        self.knobInsideLayer.cornerRadius = self.knobLayer.bounds.size.height / 2.0;
    }
    [CATransaction commit];
}

- (CGRect)rectForKnob {
    CGFloat knobHeight = self.backgroundLayer.bounds.size.height - (self.borderLineWidth * 2.0);
    
    CGFloat width = ![self isActive] ? (NSWidth(_backgroundLayer.bounds) - 2.0 * self.borderLineWidth) * 1.f / kGoldenRatio :
    (NSWidth(_backgroundLayer.bounds) - 2.0 * self.borderLineWidth) * 1.f / kDecreasedGoldenRatio;
    
    CGFloat x = ((![self hasDragged] && ![self checked]) || (self.hasDragged && ![self isDraggingTowardsOn])) ?
    self.borderLineWidth :
    NSWidth(_backgroundLayer.bounds) - width - self.borderLineWidth;
    
    return CGRectMake(x, self.borderLineWidth, width, knobHeight);
}


#pragma mark - 세터 & 게터
- (void)setChecked:(BOOL)checked {
    if (_checked != checked) {
		_checked = checked;
        [self propagateValue:@(checked) forBinding:@"checked"];
    }
    
    [self reloadLayer];
}

- (void)setTintColor:(NSColor *)tintColor {
    _tintColor = tintColor;
    [self reloadLayer];
}

- (void)setDisabledBorderColor:(NSColor *)disabledBorderColor {
    _disabledBorderColor = disabledBorderColor;
    [self reloadLayer];
}

- (CGFloat)borderLineWidth {
    return self.bounds.size.height * (2.0/31.0);
}


#pragma mark - Helpers - Action을 보낸다.
- (void)_invokeTargetAction {
    if (self.action != NULL) {
        BOOL success = [NSApp sendAction:self.action to:self.target from:self];
#if DEBUG
        if (success == YES) {
            NSLog(@"액션 보내기 성공");
        } else {
            NSLog(@"액션 보내기 실패");
        }
#endif
    }
}


#pragma mark - Bindings Extension : 선택 사항인듯.
- (void)propagateValue:(id)value forBinding:(NSBindingName)binding {
    NSParameterAssert(binding != nil); // binding 이 nil 이이면 경고!
    
    // WARNING: bindingInfo contains NSNull, so it must be accounted for
    NSDictionary <NSBindingInfoKey, id>*bindingInfo = [self infoForBinding:binding];
    if(bindingInfo == nil) { // 뭔지는 잘 모르겠는데, bindingInfo == nil로 들어온다. 잘 모르겠다. 등록하면 달라지는 듯.
        return; // there is no binding
    }
    
    // apply the value transformer, if one has been set
    NSDictionary* bindingOptions = [bindingInfo objectForKey:NSOptionsKey];
    if(bindingOptions != nil) {
        NSValueTransformer* transformer = [bindingOptions valueForKey:NSValueTransformerBindingOption];
        if(transformer == nil || (id)transformer == [NSNull null]) {
            NSString* transformerName = [bindingOptions valueForKey:NSValueTransformerNameBindingOption];
            if(transformerName && (id)transformerName != [NSNull null]){
                transformer = [NSValueTransformer valueTransformerForName:transformerName];
            }
        }
        
        if(transformer != nil && (id)transformer != [NSNull null]){
            if([[transformer class] allowsReverseTransformation]){
                value = [transformer reverseTransformedValue:value];
            } else {
                NSLog(@"WARNING: binding \"%@\" has value transformer, but it doesn't allow reverse transformations in %s", binding, __PRETTY_FUNCTION__);
            }
        }
    }
    
    id boundObject = [bindingInfo objectForKey:NSObservedObjectKey];
    if(boundObject == nil || boundObject == [NSNull null]) {
        NSLog(@"ERROR: NSObservedObjectKey was nil for binding \"%@\" in %s", binding, __PRETTY_FUNCTION__);
        return;
    }
    
    NSString* boundKeyPath = [bindingInfo objectForKey:NSObservedKeyPathKey];
    if(boundKeyPath == nil || (id)boundKeyPath == [NSNull null]) {
        NSLog(@"ERROR: NSObservedKeyPathKey was nil for binding \"%@\" in %s", binding, __PRETTY_FUNCTION__);
        return;
    }
    
    [boundObject setValue:value forKeyPath:boundKeyPath];
}


#pragma mark - <NSAccessibility> & NSObject (NSAccessibility) 관련. NSAccessibility 카테고리에서 대부분 폐기되고 <NSAccessibility>로 넘어갔는데, 뭐로 바꿔야할지 모르겠다.
//! https://bugs.chromium.org/p/chromium/issues/detail?id=386671
#pragma mark - <NSAccessibility>
- (BOOL)isAccessibilityElement { // - (BOOL)accessibilityIsIgnored API_DEPRECATED("Use isAccessibilityElement instead", macos(10.1,10.10));
    [super isAccessibilityElement];
    return NO;
}

#pragma mark - @interface NSObject (NSAccessibility)
- (id)accessibilityHitTest:(NSPoint)point {
	return self;
}

/**
- (NSArray <NSAccessibilityAttributeName>*)accessibilityAttributeNames {
	static NSArray *attributes = nil;
	if (attributes == nil)
	{
		NSMutableArray *mutableAttributes = [[super accessibilityAttributeNames] mutableCopy];
		if (mutableAttributes == nil)
			mutableAttributes = [NSMutableArray new];
		
		// Add attributes
		if (![mutableAttributes containsObject:NSAccessibilityValueAttribute])
			[mutableAttributes addObject:NSAccessibilityValueAttribute];
		
		if (![mutableAttributes containsObject:NSAccessibilityEnabledAttribute])
			[mutableAttributes addObject:NSAccessibilityEnabledAttribute];
		
		if (![mutableAttributes containsObject:NSAccessibilityDescriptionAttribute])
			[mutableAttributes addObject:NSAccessibilityDescriptionAttribute];
		
		// Remove attributes
		if ([mutableAttributes containsObject:NSAccessibilityChildrenAttribute])
			[mutableAttributes removeObject:NSAccessibilityChildrenAttribute];
		
		attributes = [mutableAttributes copy];
	}
	return attributes;
}

- (id)accessibilityAttributeValue:(NSAccessibilityAttributeName)attribute {
	id retVal = nil;
	if ([attribute isEqualToString:NSAccessibilityRoleAttribute])
		retVal = NSAccessibilityCheckBoxRole;
	else if ([attribute isEqualToString:NSAccessibilityValueAttribute])
		retVal = [NSNumber numberWithInt:self.checked];
	else if ([attribute isEqualToString:NSAccessibilityEnabledAttribute])
		retVal = [NSNumber numberWithBool:self.enabled];
	else
		retVal = [super accessibilityAttributeValue:attribute];
	return retVal;
}

- (BOOL)accessibilityIsAttributeSettable:(NSAccessibilityAttributeName)attribute {
	BOOL retVal;
	if ([attribute isEqualToString:NSAccessibilityValueAttribute])
		retVal = YES;
	else if ([attribute isEqualToString:NSAccessibilityEnabledAttribute])
		retVal = NO;
	else if ([attribute isEqualToString:NSAccessibilityDescriptionAttribute])
		retVal = NO;
	else
		retVal = [super accessibilityIsAttributeSettable:attribute];
	return retVal;
}

- (void)accessibilitySetValue:(nullable id)value forAttribute:(NSAccessibilityAttributeName)attribute {
	if ([attribute isEqualToString:NSAccessibilityValueAttribute]) {
		BOOL invokeTargetAction = self.checked != [value boolValue];
		self.checked = [value boolValue];
		if (invokeTargetAction) {
			[self _invokeTargetAction];
		}
	}
	else {
		[super accessibilitySetValue:value forAttribute:attribute];
	}
}

- (NSArray<NSAccessibilityActionName> *)accessibilityActionNames {
	static NSArray *actions = nil;
	if (actions == nil)
	{
		NSMutableArray *mutableActions = [[super accessibilityActionNames] mutableCopy];
		if (mutableActions == nil)
			mutableActions = [NSMutableArray new];
		if (![mutableActions containsObject:NSAccessibilityPressAction])
			[mutableActions addObject:NSAccessibilityPressAction];
		actions = [mutableActions copy];
	}
	return actions;
}

- (void)accessibilityPerformAction:(NSAccessibilityActionName)action {
	if ([action isEqualToString:NSAccessibilityPressAction]) {
		self.checked = ![self checked];
		[self _invokeTargetAction];
	}
	else {
		[super accessibilityPerformAction:action];
	}
}

**/

@end
