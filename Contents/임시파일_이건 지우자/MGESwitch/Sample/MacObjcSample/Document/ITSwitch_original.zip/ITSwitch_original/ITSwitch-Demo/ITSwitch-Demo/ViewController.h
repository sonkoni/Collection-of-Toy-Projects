//
//  ViewController.h
//  ITSwitch-Demo
//
//  Created by Ilija Tovilo on 01.04.18.
//  Copyright © 2018 Ilija Tovilo. All rights reserved.
//

#import <Cocoa/Cocoa.h>
@class ITSwitch;

@interface ViewController : NSViewController

@property (weak, nonatomic) IBOutlet ITSwitch *sw0;
@property (weak, nonatomic) IBOutlet ITSwitch *sw1;
@property (weak, nonatomic) IBOutlet ITSwitch *sw2;
@property (weak, nonatomic) IBOutlet ITSwitch *sw3;

@end

