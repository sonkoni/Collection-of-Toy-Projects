//
//  ViewController.m
//  ITSwitch-Demo
//
//  Created by Ilija Tovilo on 01.04.18.
//  Copyright © 2018 Ilija Tovilo. All rights reserved.
//

#import "ViewController.h"
#import "ITSwitch.h"

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view.
    
    
    self.sw0.target = self;
    self.sw0.action = @selector(switchPress:);
    self.sw1.target = self;
    self.sw1.action = @selector(switchPress:);
    self.sw2.target = self;
    self.sw2.action = @selector(switchPress:);
    self.sw3.target = self;
    self.sw3.action = @selector(switchPress:);
}


- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}

- (IBAction)switchPress:(ITSwitch *)sender {
    NSLog(@"Switch is now: %d", sender.checked);
    
}

@end

//@IBAction func switchPress(_ sender: Any) {
//    NSLog("Switch is now: \((sender as! OGSwitch).isOn)")
//   // perform(#selector(timer), with: nil, afterDelay: 3)
//}
