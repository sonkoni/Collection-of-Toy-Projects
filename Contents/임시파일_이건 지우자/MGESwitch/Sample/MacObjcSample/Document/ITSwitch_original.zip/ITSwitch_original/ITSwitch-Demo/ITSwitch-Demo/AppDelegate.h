//
//  AppDelegate.h
//  ITSwitch-Demo
//
//  Created by Ilija Tovilo on 01.04.18.
//  Copyright © 2018 Ilija Tovilo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

